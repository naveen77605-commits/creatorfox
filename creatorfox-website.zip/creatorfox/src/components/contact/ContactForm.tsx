"use client";

import { useState } from "react";
import { useRouter } from "next/navigation";
import { ArrowUpRight, Loader2 } from "lucide-react";
import { services } from "@/data/services";

/*
 * Lead form. Wire `FORM_ENDPOINT` to your handler (Formspree, Basin,
 * your CRM webhook, or a Next.js route handler). Until then it
 * simulates success and routes to /thank-you so the flow is testable.
 */
const FORM_ENDPOINT = ""; // e.g. "https://formspree.io/f/xxxxxxx"

const budgets = ["Under ₹1L / month", "₹1–3L / month", "₹3–10L / month", "₹10L+ / month", "Fixed-scope project"];

const inputCls =
  "w-full rounded-xl border border-bone/15 bg-bone/[0.04] px-4 py-3.5 text-sm text-bone placeholder:text-smoke focus:border-gold focus:outline-none transition-colors";

export default function ContactForm() {
  const router = useRouter();
  const [sending, setSending] = useState(false);
  const [error, setError] = useState<string | null>(null);

  async function onSubmit(e: React.FormEvent<HTMLFormElement>) {
    e.preventDefault();
    setError(null);
    setSending(true);
    const form = e.currentTarget;

    try {
      if (FORM_ENDPOINT) {
        const res = await fetch(FORM_ENDPOINT, {
          method: "POST",
          body: new FormData(form),
          headers: { Accept: "application/json" },
        });
        if (!res.ok) throw new Error("Submission failed");
      } else {
        await new Promise((r) => setTimeout(r, 900));
      }
      router.push("/thank-you");
    } catch {
      setSending(false);
      setError("Something went wrong sending your message. Email us directly at make@creatorfox.com and we'll reply the same day.");
    }
  }

  return (
    <form onSubmit={onSubmit} className="grid gap-5" noValidate={false}>
      <div className="grid gap-5 sm:grid-cols-2">
        <div>
          <label htmlFor="cf-name" className="eyebrow mb-2 block">Your name *</label>
          <input id="cf-name" name="name" required autoComplete="name" placeholder="Priya Sharma" className={inputCls} />
        </div>
        <div>
          <label htmlFor="cf-company" className="eyebrow mb-2 block">Company</label>
          <input id="cf-company" name="company" autoComplete="organization" placeholder="Acme Pvt. Ltd." className={inputCls} />
        </div>
      </div>

      <div className="grid gap-5 sm:grid-cols-2">
        <div>
          <label htmlFor="cf-email" className="eyebrow mb-2 block">Email *</label>
          <input id="cf-email" name="email" type="email" required autoComplete="email" placeholder="you@company.com" className={inputCls} />
        </div>
        <div>
          <label htmlFor="cf-phone" className="eyebrow mb-2 block">Phone / WhatsApp</label>
          <input id="cf-phone" name="phone" type="tel" autoComplete="tel" placeholder="+91 98765 43210" className={inputCls} />
        </div>
      </div>

      <div className="grid gap-5 sm:grid-cols-2">
        <div>
          <label htmlFor="cf-service" className="eyebrow mb-2 block">What do you need? *</label>
          <select id="cf-service" name="service" required defaultValue="" className={inputCls}>
            <option value="" disabled>Choose a service</option>
            {services.map((s) => (
              <option key={s.slug} value={s.name}>{s.name}</option>
            ))}
            <option value="Multiple / not sure">Multiple / not sure yet</option>
          </select>
        </div>
        <div>
          <label htmlFor="cf-budget" className="eyebrow mb-2 block">Monthly budget</label>
          <select id="cf-budget" name="budget" defaultValue="" className={inputCls}>
            <option value="" disabled>Choose a range</option>
            {budgets.map((b) => (
              <option key={b} value={b}>{b}</option>
            ))}
          </select>
        </div>
      </div>

      <div>
        <label htmlFor="cf-message" className="eyebrow mb-2 block">Tell us about the goal *</label>
        <textarea
          id="cf-message"
          name="message"
          required
          rows={5}
          placeholder="Where's the business today, and what should be different in 12 months?"
          className={inputCls}
        />
      </div>

      {error && (
        <p role="alert" className="rounded-xl border border-red-400/40 bg-red-400/10 px-4 py-3 text-sm text-red-200">
          {error}
        </p>
      )}

      <button
        type="submit"
        disabled={sending}
        data-cursor
        className="group inline-flex w-fit items-center gap-2.5 rounded-full bg-gold px-8 py-4 text-sm font-bold text-carbon transition-colors hover:bg-gold-hot disabled:opacity-60"
      >
        {sending ? (
          <>
            Sending <Loader2 size={16} className="animate-spin" aria-hidden />
          </>
        ) : (
          <>
            Send the brief
            <ArrowUpRight size={16} strokeWidth={2.5} className="transition-transform group-hover:translate-x-0.5 group-hover:-translate-y-0.5" aria-hidden />
          </>
        )}
      </button>
      <p className="text-xs text-smoke">
        We reply within one business day. Your details are never shared — see our{" "}
        <a href="/privacy-policy" className="underline hover:text-gold">privacy policy</a>.
      </p>
    </form>
  );
}
