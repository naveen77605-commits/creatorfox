import Link from "next/link";
import { ArrowUpRight } from "lucide-react";
import { Reveal, SplitReveal, ScentLine } from "@/components/ui/Reveal";
import { caseStudies } from "@/data/case-studies";

/*
 * Selected work — editorial, asymmetric case study cards with
 * generative gradient art instead of stock photography.
 */
export default function CaseStudiesSection() {
  const featured = caseStudies.slice(0, 3);

  return (
    <section className="bg-bone py-24 text-carbon sm:py-32">
      <div className="wrap">
        <p className="eyebrow-light mb-6">Selected work</p>
        <div className="flex flex-wrap items-end justify-between gap-6">
          <SplitReveal as="h2" className="max-w-3xl font-display text-display-md font-medium">
            Proof beats <em className="accent-word">promises.</em>
          </SplitReveal>
          <Link
            href="/case-studies"
            data-cursor
            className="group mb-2 inline-flex items-center gap-2 text-sm font-bold hover:text-gold-deep"
          >
            All case studies
            <ArrowUpRight size={16} className="transition-transform group-hover:translate-x-0.5 group-hover:-translate-y-0.5" aria-hidden />
          </Link>
        </div>
        <ScentLine className="mt-10" />

        <div className="mt-14 grid gap-8 lg:gap-10">
          {featured.map((cs, i) => (
            <Reveal key={cs.slug} delay={0.05 * i}>
              <Link
                href="/case-studies"
                data-cursor-label="Read"
                className={`group grid items-stretch gap-0 overflow-hidden rounded-3xl bg-white shadow-[0_30px_80px_-40px_rgba(11,10,7,0.35)] transition-transform duration-500 ease-out hover:-translate-y-1.5 lg:grid-cols-5 ${
                  i % 2 ? "lg:[direction:rtl]" : ""
                }`}
              >
                {/* generative art panel */}
                <div className="relative min-h-[14rem] overflow-hidden lg:col-span-2 lg:[direction:ltr]">
                  <div
                    className="absolute inset-0 transition-transform duration-700 ease-out group-hover:scale-105"
                    style={{
                      background: `linear-gradient(${cs.art.angle}deg, ${cs.art.from}, ${cs.art.via} 45%, ${cs.art.to})`,
                    }}
                    aria-hidden
                  />
                  <div className="absolute inset-0 opacity-40 mix-blend-overlay" aria-hidden
                    style={{
                      backgroundImage:
                        "radial-gradient(circle at 30% 30%, rgba(255,255,255,0.5), transparent 40%), radial-gradient(circle at 75% 80%, rgba(0,0,0,0.45), transparent 45%)",
                    }}
                  />
                  <p className="absolute bottom-5 left-6 font-display text-xl font-semibold text-white/90">
                    {cs.client}
                  </p>
                </div>

                {/* story panel */}
                <div className="flex flex-col justify-between gap-8 p-8 sm:p-10 lg:col-span-3 lg:[direction:ltr]">
                  <div>
                    <p className="eyebrow-light">{cs.industry}</p>
                    <h3 className="mt-4 max-w-xl font-display text-2xl font-medium leading-snug sm:text-3xl">
                      {cs.headline}
                    </h3>
                    <div className="mt-4 flex flex-wrap gap-2">
                      {cs.services.map((s) => (
                        <span
                          key={s}
                          className="rounded-full border border-carbon/15 px-3 py-1 text-xs font-medium text-smoke-dark"
                        >
                          {s}
                        </span>
                      ))}
                    </div>
                  </div>
                  <dl className="grid grid-cols-3 gap-4 border-t border-carbon/10 pt-6">
                    {cs.metrics.map((m) => (
                      <div key={m.label}>
                        <dt className="sr-only">{m.label}</dt>
                        <dd className="font-display text-2xl font-semibold text-gold-deep sm:text-3xl">
                          {m.value}
                        </dd>
                        <dd className="mt-1 text-xs leading-snug text-smoke-dark">{m.label}</dd>
                      </div>
                    ))}
                  </dl>
                </div>
              </Link>
            </Reveal>
          ))}
        </div>
      </div>
    </section>
  );
}
