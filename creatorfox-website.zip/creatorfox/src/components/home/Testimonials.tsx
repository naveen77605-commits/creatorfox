"use client";

import { useState } from "react";
import { Quote } from "lucide-react";
import { SplitReveal } from "@/components/ui/Reveal";
import { testimonials } from "@/data/site";
import { cn } from "@/lib/utils";

/*
 * Testimonials — one voice at a time, switched with an index rail.
 */
export default function Testimonials() {
  const [active, setActive] = useState(0);
  const t = testimonials[active];

  return (
    <section className="grain relative overflow-hidden bg-carbon py-24 sm:py-32">
      <div className="wrap grid gap-14 lg:grid-cols-[1fr_2fr]">
        <div>
          <p className="eyebrow mb-6">Client voices</p>
          <SplitReveal as="h2" className="font-display text-display-sm font-medium text-bone">
            The reviews we <em className="accent-word">work</em> for.
          </SplitReveal>

          <div className="mt-10 flex gap-3" role="tablist" aria-label="Choose a testimonial">
            {testimonials.map((item, i) => (
              <button
                key={item.name}
                role="tab"
                aria-selected={active === i}
                aria-label={`Testimonial from ${item.name}`}
                onClick={() => setActive(i)}
                data-cursor
                className={cn(
                  "h-1.5 rounded-full transition-all duration-500 ease-swift",
                  active === i ? "w-12 bg-gold" : "w-6 bg-bone/20 hover:bg-bone/40"
                )}
              />
            ))}
          </div>
        </div>

        <figure key={active} className="relative">
          <Quote size={44} className="absolute -left-2 -top-4 rotate-180 text-gold/25" aria-hidden />
          <blockquote className="relative pl-8 sm:pl-12">
            <p className="animate-[fadeSlide_0.6s_ease-out] font-display text-2xl font-medium leading-snug text-bone sm:text-[2rem]">
              “{t.quote}”
            </p>
            <figcaption className="mt-8">
              <p className="font-bold text-gold">{t.name}</p>
              <p className="mt-1 text-sm text-smoke">{t.role}</p>
            </figcaption>
          </blockquote>
        </figure>
      </div>

      <style>{`
        @keyframes fadeSlide {
          from { opacity: 0; transform: translateY(18px); }
          to { opacity: 1; transform: translateY(0); }
        }
      `}</style>
    </section>
  );
}
