"use client";

import { useEffect, useRef, useState } from "react";
import dynamic from "next/dynamic";
import { gsap, SplitText, prefersReducedMotion } from "@/lib/gsap";
import CtaButton from "@/components/ui/CtaButton";
import Counter from "@/components/ui/Counter";
import { stats } from "@/data/site";

const HeroScene = dynamic(() => import("@/components/three/HeroScene"), {
  ssr: false,
  loading: () => null,
});

export default function Hero() {
  const root = useRef<HTMLElement>(null);
  const [reduced, setReduced] = useState(false);

  useEffect(() => {
    setReduced(prefersReducedMotion());
  }, []);

  useEffect(() => {
    const el = root.current;
    if (!el || prefersReducedMotion()) return;

    let split: SplitText | undefined;
    const ctx = gsap.context(() => {
      split = new SplitText(".hero-headline", { type: "lines", mask: "lines" });
      const tl = gsap.timeline({ delay: 0.25, defaults: { ease: "power4.out" } });
      tl.from(".hero-eyebrow", { autoAlpha: 0, y: 20, duration: 0.8 })
        .from(split.lines, { yPercent: 115, duration: 1.2, stagger: 0.1 }, "-=0.4")
        .from(".hero-sub", { autoAlpha: 0, y: 26, duration: 0.9 }, "-=0.7")
        .from(".hero-ctas", { autoAlpha: 0, y: 26, duration: 0.9 }, "-=0.7")
        .from(".hero-stat", { autoAlpha: 0, y: 34, stagger: 0.09, duration: 0.8 }, "-=0.6")
        .from(".hero-scroll-hint", { autoAlpha: 0, duration: 1 }, "-=0.3");

      /* gentle levitation for the stat cards */
      gsap.utils.toArray<HTMLElement>(".hero-stat").forEach((card, i) => {
        gsap.to(card, {
          y: i % 2 ? -10 : -16,
          duration: 2.6 + i * 0.35,
          ease: "sine.inOut",
          yoyo: true,
          repeat: -1,
          delay: 1.8,
        });
      });

      /* parallax the scene container as you leave the hero */
      gsap.to(".hero-scene", {
        yPercent: 18,
        autoAlpha: 0.25,
        ease: "none",
        scrollTrigger: { trigger: el, start: "top top", end: "bottom top", scrub: true },
      });
    }, el);

    return () => {
      split?.revert();
      ctx.revert();
    };
  }, []);

  return (
    <section
      ref={root}
      className="grain relative flex min-h-[100svh] flex-col justify-center overflow-hidden bg-carbon pb-24 pt-36 lg:pb-28"
    >
      {/* 3D particle galaxy */}
      <div className="hero-scene absolute inset-0" aria-hidden="true">
        <div className="absolute left-1/2 top-1/2 h-[70vmin] w-[70vmin] -translate-x-1/2 -translate-y-1/2 rounded-full bg-gold/10 blur-[120px]" />
        <HeroScene reduced={reduced} />
      </div>
      {/* readability veil */}
      <div
        className="absolute inset-0 bg-gradient-to-b from-carbon/70 via-transparent to-carbon"
        aria-hidden="true"
      />

      <div className="wrap relative z-10">
        <p className="hero-eyebrow eyebrow mb-8">
          Global digital agency — Bengaluru · Dubai · Sydney · Dortmund
        </p>

        <h1 className="hero-headline max-w-5xl font-display text-display-xl font-semibold text-bone">
          Brands that <em className="accent-word">outfox</em> the market.
        </h1>

        <p className="hero-sub mt-8 max-w-xl text-lg leading-relaxed text-bone/75">
          CreatorFox is a full-service digital marketing and web development agency. One team for
          your brand, your website and your growth — measured in revenue, not impressions.
        </p>

        <div className="hero-ctas mt-10 flex flex-wrap items-center gap-4">
          <CtaButton href="/contact">Book a free strategy call</CtaButton>
          <CtaButton href="/case-studies" variant="outline">
            See our work
          </CtaButton>
        </div>

        {/* floating proof */}
        <div className="mt-16 grid max-w-3xl grid-cols-2 gap-3 sm:grid-cols-4 lg:mt-20">
          {stats.map((s) => (
            <div key={s.label} className="hero-stat glass rounded-2xl p-4 sm:p-5">
              <p className="font-display text-2xl font-semibold text-gold sm:text-3xl">
                <Counter value={s.value} suffix={s.suffix} />
              </p>
              <p className="mt-1.5 text-xs leading-snug text-bone/65">{s.label}</p>
            </div>
          ))}
        </div>
      </div>

      <div
        className="hero-scroll-hint absolute bottom-7 left-1/2 z-10 -translate-x-1/2"
        aria-hidden="true"
      >
        <div className="flex h-12 w-7 items-start justify-center rounded-full border border-bone/25 p-1.5">
          <span className="h-2.5 w-[3px] animate-bounce rounded-full bg-gold" />
        </div>
      </div>
    </section>
  );
}
