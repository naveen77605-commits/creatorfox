"use client";

import { useEffect, useRef } from "react";
import { gsap, prefersReducedMotion } from "@/lib/gsap";
import { Reveal, SplitReveal } from "@/components/ui/Reveal";

/*
 * The Hunt — CreatorFox's five-step process as a scroll-driven timeline.
 * A gold line draws downward as each numbered step comes alive.
 */

const steps = [
  {
    title: "Scent",
    subtitle: "Discovery & audit",
    desc: "We study your market, your numbers and your funnel before we touch anything. Every engagement starts with evidence: where the demand is, where you're leaking it, and what's worth doing first.",
  },
  {
    title: "Track",
    subtitle: "Strategy & roadmap",
    desc: "A plan you could take anywhere — but won't want to. Positioning, channels, budgets and a 90-day roadmap with owners and numbers attached to every line.",
  },
  {
    title: "Stalk",
    subtitle: "Build & create",
    desc: "Design, engineering, content and campaigns produced by one in-house team. You review work-in-progress weekly, not a big reveal after two months of silence.",
  },
  {
    title: "Strike",
    subtitle: "Launch & optimise",
    desc: "Ship, measure, adjust — fast. Landing pages, ads and automations go live with tracking that ties every rupee of spend to an outcome.",
  },
  {
    title: "Feast",
    subtitle: "Scale & compound",
    desc: "Winners get budget, learnings get documented, and the system compounds. Monthly reports read like a P&L, not a screenshot dump.",
  },
];

export default function Process() {
  const root = useRef<HTMLElement>(null);

  useEffect(() => {
    const el = root.current;
    if (!el || prefersReducedMotion()) return;

    const ctx = gsap.context(() => {
      gsap.from(".process-line-fill", {
        scaleY: 0,
        ease: "none",
        scrollTrigger: {
          trigger: ".process-list",
          start: "top 70%",
          end: "bottom 55%",
          scrub: 0.6,
        },
      });

      gsap.utils.toArray<HTMLElement>(".process-step").forEach((step) => {
        gsap.from(step, {
          autoAlpha: 0,
          x: -36,
          duration: 0.9,
          ease: "power3.out",
          scrollTrigger: { trigger: step, start: "top 78%", once: true },
        });
      });
    }, el);

    return () => ctx.revert();
  }, []);

  return (
    <section ref={root} className="grain relative overflow-hidden bg-carbon py-24 sm:py-32">
      <div className="wrap grid gap-16 lg:grid-cols-[1fr_1.4fr]">
        <div className="lg:sticky lg:top-32 lg:self-start">
          <p className="eyebrow mb-6">Why CreatorFox</p>
          <SplitReveal as="h2" className="font-display text-display-md font-medium text-bone">
            We hunt growth the way a fox hunts — <em className="accent-word">patiently, then precisely.</em>
          </SplitReveal>
          <Reveal as="p" className="mt-6 max-w-md text-base leading-relaxed text-smoke" delay={0.15}>
            No spray-and-pray campaigns. No reports that need a translator. Our five-step method has
            shipped 640+ projects across four countries — and it starts by understanding your
            business better than your last agency ever tried to.
          </Reveal>
        </div>

        <ol className="process-list relative list-none">
          {/* timeline spine */}
          <span className="absolute bottom-6 left-[1.35rem] top-6 w-px bg-bone/10 sm:left-[1.6rem]" aria-hidden>
            <span className="process-line-fill absolute inset-0 origin-top bg-gradient-to-b from-gold via-gold to-gold/20" />
          </span>

          {steps.map((s, i) => (
            <li key={s.title} className="process-step relative flex gap-6 pb-14 pl-0 last:pb-0 sm:gap-8">
              <span
                className="relative z-10 flex h-11 w-11 shrink-0 items-center justify-center rounded-full border border-gold/40 bg-carbon font-mono text-xs text-gold sm:h-[3.2rem] sm:w-[3.2rem]"
                aria-hidden
              >
                {String(i + 1).padStart(2, "0")}
              </span>
              <div className="pt-1.5">
                <h3 className="font-display text-2xl font-medium text-bone sm:text-3xl">
                  {s.title}
                  <span className="ml-3 align-middle font-mono text-[0.65rem] uppercase tracking-[0.25em] text-gold">
                    {s.subtitle}
                  </span>
                </h3>
                <p className="mt-3 max-w-lg text-sm leading-relaxed text-smoke sm:text-base">{s.desc}</p>
              </div>
            </li>
          ))}
        </ol>
      </div>
    </section>
  );
}
