import Counter from "@/components/ui/Counter";
import { Reveal } from "@/components/ui/Reveal";

/*
 * Metrics band — the one loud gold moment on the page.
 */
const metrics = [
  { value: 250, suffix: "+", label: "clients across 4 countries" },
  { value: 640, suffix: "+", label: "projects shipped since 2018" },
  { value: 12, suffix: "", label: "in-house disciplines under one roof" },
  { value: 93, suffix: "%", label: "of clients stay past year one" },
];

export default function MetricsBand() {
  return (
    <section aria-label="CreatorFox in numbers" className="bg-gold py-16 text-carbon sm:py-20">
      <div className="wrap grid grid-cols-2 gap-x-6 gap-y-10 lg:grid-cols-4">
        {metrics.map((m, i) => (
          <Reveal key={m.label} delay={0.06 * i}>
            <p className="font-display text-5xl font-semibold tracking-tight sm:text-6xl">
              <Counter value={m.value} suffix={m.suffix} />
            </p>
            <p className="mt-2 max-w-[14rem] text-sm font-medium leading-snug text-carbon/75">
              {m.label}
            </p>
          </Reveal>
        ))}
      </div>
    </section>
  );
}
