import Link from "next/link";
import { ArrowUpRight } from "lucide-react";
import { Reveal, SplitReveal, ScentLine } from "@/components/ui/Reveal";
import { blogPosts } from "@/data/content";

export default function InsightsStrip() {
  const posts = blogPosts.slice(0, 3);

  return (
    <section className="grain relative bg-carbon py-24 sm:py-32">
      <div className="wrap">
        <p className="eyebrow mb-6">Insights</p>
        <div className="flex flex-wrap items-end justify-between gap-6">
          <SplitReveal as="h2" className="max-w-3xl font-display text-display-sm font-medium text-bone">
            Thinking we <em className="accent-word">publish,</em> tactics we use.
          </SplitReveal>
          <Link
            href="/blog"
            data-cursor
            className="group mb-2 inline-flex items-center gap-2 text-sm font-bold text-bone hover:text-gold"
          >
            All articles
            <ArrowUpRight size={16} className="transition-transform group-hover:translate-x-0.5 group-hover:-translate-y-0.5" aria-hidden />
          </Link>
        </div>
        <ScentLine className="mt-10" />

        <div className="mt-12 grid gap-5 md:grid-cols-3">
          {posts.map((post, i) => (
            <Reveal key={post.slug} delay={0.07 * i}>
              <Link
                href="/blog"
                data-cursor-label="Read"
                className="group flex h-full flex-col justify-between rounded-3xl border border-bone/10 p-7 transition-colors duration-500 hover:border-gold/40 hover:bg-bone/[0.03]"
              >
                <div>
                  <div className="flex items-center gap-3 text-xs text-smoke">
                    <span className="rounded-full border border-gold/30 px-3 py-1 font-medium text-gold">
                      {post.category}
                    </span>
                    <span>{post.readTime}</span>
                  </div>
                  <h3 className="mt-5 font-display text-xl font-medium leading-snug text-bone group-hover:text-gold">
                    {post.title}
                  </h3>
                  <p className="mt-3 text-sm leading-relaxed text-smoke">{post.excerpt}</p>
                </div>
                <p className="mt-6 inline-flex items-center gap-2 text-sm font-bold text-gold">
                  Read article
                  <ArrowUpRight size={14} className="transition-transform group-hover:translate-x-0.5 group-hover:-translate-y-0.5" aria-hidden />
                </p>
              </Link>
            </Reveal>
          ))}
        </div>
      </div>
    </section>
  );
}
