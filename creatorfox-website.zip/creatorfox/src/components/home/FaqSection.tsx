import Accordion from "@/components/ui/Accordion";
import { SplitReveal, Reveal } from "@/components/ui/Reveal";
import CtaButton from "@/components/ui/CtaButton";
import { homeFaqs } from "@/data/site";

export default function FaqSection() {
  return (
    <section className="bg-bone py-24 text-carbon sm:py-32">
      <div className="wrap grid gap-14 lg:grid-cols-[1fr_1.6fr]">
        <div className="lg:sticky lg:top-32 lg:self-start">
          <p className="eyebrow-light mb-6">Questions, answered</p>
          <SplitReveal as="h2" className="font-display text-display-sm font-medium">
            Everything founders <em className="accent-word">ask us</em> first.
          </SplitReveal>
          <Reveal as="p" className="mt-6 max-w-sm text-base leading-relaxed text-smoke-dark" delay={0.1}>
            Something more specific? Bring it to a free strategy call — twenty minutes, no deck, no
            pressure.
          </Reveal>
          <Reveal delay={0.2} className="mt-8">
            <CtaButton href="/contact" variant="outline-light">
              Ask us directly
            </CtaButton>
          </Reveal>
        </div>

        <Reveal delay={0.1}>
          <Accordion items={homeFaqs} light />
        </Reveal>
      </div>
    </section>
  );
}
