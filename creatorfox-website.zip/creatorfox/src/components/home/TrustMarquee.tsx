import Marquee from "@/components/ui/Marquee";
import { industries } from "@/data/site";

/*
 * Trust band — industries we serve, as an infinite marquee.
 * Swap the text items for client logo SVGs when approvals are in place.
 */
export default function TrustMarquee() {
  return (
    <section aria-label="Industries CreatorFox works with" className="border-y border-bone/10 bg-carbon py-7">
      <Marquee duration={46}>
        {industries.map((ind) => (
          <span key={ind.name} className="mx-8 flex items-center gap-8 whitespace-nowrap">
            <span className="font-display text-lg font-medium text-bone/45 transition-colors hover:text-gold">
              {ind.name}
            </span>
            <span className="h-1.5 w-1.5 rounded-full bg-gold/50" aria-hidden />
          </span>
        ))}
      </Marquee>
    </section>
  );
}
