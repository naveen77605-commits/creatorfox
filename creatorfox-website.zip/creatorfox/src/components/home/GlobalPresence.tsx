import { Reveal, SplitReveal } from "@/components/ui/Reveal";
import CtaButton from "@/components/ui/CtaButton";
import { offices } from "@/data/site";

/*
 * Global presence — four offices on an abstract signal grid.
 * Pulsing gold nodes; no clichéd world map raster.
 */
export default function GlobalPresence() {
  return (
    <section className="relative overflow-hidden bg-coal py-24 sm:py-32">
      {/* signal grid backdrop */}
      <div
        className="absolute inset-0 opacity-[0.13]"
        aria-hidden
        style={{
          backgroundImage:
            "linear-gradient(rgba(243,188,9,0.5) 1px, transparent 1px), linear-gradient(90deg, rgba(243,188,9,0.5) 1px, transparent 1px)",
          backgroundSize: "72px 72px",
          maskImage: "radial-gradient(80% 80% at 50% 50%, black, transparent)",
          WebkitMaskImage: "radial-gradient(80% 80% at 50% 50%, black, transparent)",
        }}
      />

      <div className="wrap relative z-10">
        <p className="eyebrow mb-6">Global presence</p>
        <div className="flex flex-wrap items-end justify-between gap-8">
          <SplitReveal as="h2" className="max-w-3xl font-display text-display-md font-medium text-bone">
            Four offices. <em className="accent-word">Every</em> timezone covered.
          </SplitReveal>
          <CtaButton href="/contact" variant="outline" className="mb-2">
            Find your nearest team
          </CtaButton>
        </div>

        <div className="mt-16 grid gap-5 sm:grid-cols-2 lg:grid-cols-4">
          {offices.map((o, i) => (
            <Reveal key={o.city} delay={0.07 * i}>
              <article className="group relative h-full rounded-3xl border border-bone/10 bg-carbon/70 p-7 backdrop-blur transition-colors duration-500 hover:border-gold/40">
                <span className="relative flex h-3 w-3" aria-hidden>
                  <span className="absolute inline-flex h-full w-full animate-ping rounded-full bg-gold/50 [animation-duration:2.2s]" />
                  <span className="relative inline-flex h-3 w-3 rounded-full bg-gold" />
                </span>
                <h3 className="mt-5 font-display text-2xl font-medium text-bone">{o.city}</h3>
                <p className="mt-0.5 text-sm text-gold">{o.label} · {o.timezone}</p>
                <p className="mt-4 text-xs leading-relaxed text-smoke">{o.address}</p>
                <a
                  href={`tel:${o.phone.replace(/[^+\d]/g, "")}`}
                  className="mt-4 inline-block text-sm font-medium text-bone/80 hover:text-gold"
                >
                  {o.phone}
                </a>
              </article>
            </Reveal>
          ))}
        </div>
      </div>
    </section>
  );
}
