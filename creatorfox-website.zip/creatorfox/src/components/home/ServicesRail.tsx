"use client";

import { useEffect, useRef } from "react";
import Link from "next/link";
import { ArrowUpRight } from "lucide-react";
import { gsap, prefersReducedMotion } from "@/lib/gsap";
import { SplitReveal } from "@/components/ui/Reveal";
import { getService } from "@/data/services";

/*
 * Services rail — light section, pinned horizontal scroll on desktop,
 * vertical stack on mobile. Each card carries its own gradient field.
 */

const featured = [
  "seo",
  "google-ads",
  "meta-ads",
  "social-media-marketing",
  "website-development",
  "shopify-development",
  "branding",
  "ai-automation",
];

const fields = [
  "radial-gradient(120% 120% at 20% 20%, rgba(243,188,9,0.35), transparent 60%)",
  "radial-gradient(120% 120% at 80% 30%, rgba(243,188,9,0.28), transparent 55%)",
  "radial-gradient(130% 130% at 30% 80%, rgba(154,113,0,0.4), transparent 60%)",
  "radial-gradient(120% 120% at 70% 70%, rgba(255,217,74,0.3), transparent 55%)",
];

export default function ServicesRail() {
  const root = useRef<HTMLElement>(null);
  const track = useRef<HTMLDivElement>(null);

  useEffect(() => {
    const section = root.current;
    const rail = track.current;
    if (!section || !rail || prefersReducedMotion()) return;

    const mm = gsap.matchMedia();
    mm.add("(min-width: 1024px)", () => {
      const distance = () => rail.scrollWidth - window.innerWidth;
      const tween = gsap.to(rail, {
        x: () => -distance(),
        ease: "none",
        scrollTrigger: {
          trigger: section,
          start: "top top",
          end: () => `+=${distance()}`,
          pin: true,
          scrub: 1,
          invalidateOnRefresh: true,
        },
      });
      return () => {
        tween.scrollTrigger?.kill();
        tween.kill();
      };
    });

    return () => mm.revert();
  }, []);

  return (
    <section ref={root} className="overflow-hidden bg-bone text-carbon">
      <div className="wrap pt-24 sm:pt-32">
        <p className="eyebrow-light mb-6">What we do</p>
        <div className="flex flex-wrap items-end justify-between gap-6">
          <SplitReveal as="h2" className="max-w-3xl font-display text-display-md font-medium">
            Fourteen disciplines. <em className="accent-word">One</em> accountable team.
          </SplitReveal>
          <Link
            href="/services"
            data-cursor
            className="group mb-2 inline-flex items-center gap-2 text-sm font-bold text-carbon hover:text-gold-deep"
          >
            All services
            <ArrowUpRight size={16} className="transition-transform group-hover:translate-x-0.5 group-hover:-translate-y-0.5" aria-hidden />
          </Link>
        </div>
      </div>

      <div
        ref={track}
        className="mt-14 flex flex-col gap-5 px-5 pb-24 sm:px-8 lg:mt-20 lg:w-max lg:flex-row lg:gap-8 lg:px-14 lg:pb-32"
      >
        {featured.map((slug, i) => {
          const s = getService(slug);
          if (!s) return null;
          return (
            <Link
              key={slug}
              href={`/services/${slug}`}
              data-cursor-label="Explore"
              className="group relative flex min-h-[22rem] flex-col justify-between overflow-hidden rounded-3xl bg-carbon p-8 text-bone shadow-[0_24px_60px_-30px_rgba(11,10,7,0.5)] transition-transform duration-500 ease-out hover:-translate-y-2 sm:p-10 lg:w-[26rem] lg:shrink-0"
            >
              <div
                className="absolute inset-0 opacity-80 transition-opacity duration-700 group-hover:opacity-100"
                style={{ background: fields[i % fields.length] }}
                aria-hidden
              />
              <div className="relative z-10 flex items-start justify-between">
                <p className="eyebrow">{s.category}</p>
                <ArrowUpRight
                  size={22}
                  className="text-gold transition-transform duration-500 group-hover:translate-x-1 group-hover:-translate-y-1"
                  aria-hidden
                />
              </div>
              <div className="relative z-10">
                <h3 className="font-display text-3xl font-medium sm:text-4xl">{s.name}</h3>
                <p className="mt-3 max-w-xs text-sm leading-relaxed text-bone/70">{s.short}</p>
              </div>
            </Link>
          );
        })}

        {/* terminal card */}
        <Link
          href="/services"
          data-cursor-label="View all"
          className="group relative flex min-h-[22rem] flex-col items-start justify-end overflow-hidden rounded-3xl border-2 border-dashed border-carbon/25 p-8 text-carbon transition-colors duration-500 hover:border-gold sm:p-10 lg:w-[22rem] lg:shrink-0"
        >
          <p className="font-display text-3xl font-medium">
            + 6 more
            <br />
            disciplines
          </p>
          <p className="mt-3 inline-flex items-center gap-2 text-sm font-bold text-gold-deep">
            Browse all services <ArrowUpRight size={15} aria-hidden />
          </p>
        </Link>
      </div>
    </section>
  );
}
