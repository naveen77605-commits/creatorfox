"use client";

import { useEffect, useRef, useState } from "react";
import { gsap, prefersReducedMotion } from "@/lib/gsap";

/*
 * Custom cursor: a gold dot + trailing ring.
 * Grows over links/buttons; shows a label over [data-cursor-label] targets.
 * Renders nothing on touch devices or with reduced motion.
 */
export default function Cursor() {
  const dotRef = useRef<HTMLDivElement>(null);
  const ringRef = useRef<HTMLDivElement>(null);
  const labelRef = useRef<HTMLSpanElement>(null);
  const [enabled, setEnabled] = useState(false);

  useEffect(() => {
    if (window.matchMedia("(pointer: coarse)").matches || prefersReducedMotion()) return;
    setEnabled(true);
  }, []);

  useEffect(() => {
    if (!enabled) return;
    const dot = dotRef.current;
    const ring = ringRef.current;
    const label = labelRef.current;
    if (!dot || !ring || !label) return;

    document.documentElement.classList.add("has-cursor");

    const dotX = gsap.quickTo(dot, "x", { duration: 0.12, ease: "power2.out" });
    const dotY = gsap.quickTo(dot, "y", { duration: 0.12, ease: "power2.out" });
    const ringX = gsap.quickTo(ring, "x", { duration: 0.45, ease: "power3.out" });
    const ringY = gsap.quickTo(ring, "y", { duration: 0.45, ease: "power3.out" });

    const onMove = (e: MouseEvent) => {
      dotX(e.clientX);
      dotY(e.clientY);
      ringX(e.clientX);
      ringY(e.clientY);
    };

    const onOver = (e: MouseEvent) => {
      const target = (e.target as HTMLElement).closest("a, button, [data-cursor]");
      const labelled = (e.target as HTMLElement).closest("[data-cursor-label]");
      if (labelled) {
        label.textContent = labelled.getAttribute("data-cursor-label") || "";
        gsap.to(ring, { scale: 3.2, backgroundColor: "rgba(243,188,9,0.95)", duration: 0.3 });
        gsap.to(label, { autoAlpha: 1, duration: 0.2 });
        gsap.to(dot, { scale: 0, duration: 0.2 });
      } else if (target) {
        gsap.to(ring, { scale: 1.8, backgroundColor: "rgba(243,188,9,0.12)", duration: 0.3 });
        gsap.to(label, { autoAlpha: 0, duration: 0.2 });
        gsap.to(dot, { scale: 1.6, duration: 0.2 });
      } else {
        gsap.to(ring, { scale: 1, backgroundColor: "rgba(243,188,9,0)", duration: 0.3 });
        gsap.to(label, { autoAlpha: 0, duration: 0.2 });
        gsap.to(dot, { scale: 1, duration: 0.2 });
      }
    };

    window.addEventListener("mousemove", onMove, { passive: true });
    window.addEventListener("mouseover", onOver, { passive: true });
    return () => {
      window.removeEventListener("mousemove", onMove);
      window.removeEventListener("mouseover", onOver);
      document.documentElement.classList.remove("has-cursor");
    };
  }, [enabled]);

  if (!enabled) return null;

  return (
    <div aria-hidden="true" className="pointer-events-none fixed inset-0 z-[120] hidden md:block">
      <div
        ref={ringRef}
        className="absolute -ml-5 -mt-5 flex h-10 w-10 items-center justify-center rounded-full border border-gold/50"
        style={{ left: 0, top: 0 }}
      >
        <span
          ref={labelRef}
          className="select-none text-[3.5px] font-bold uppercase tracking-widest text-carbon opacity-0"
        />
      </div>
      <div
        ref={dotRef}
        className="absolute -ml-[3px] -mt-[3px] h-1.5 w-1.5 rounded-full bg-gold"
        style={{ left: 0, top: 0 }}
      />
    </div>
  );
}
