"use client";

import { useEffect, useRef, type ElementType, type ReactNode } from "react";
import { gsap, SplitText, prefersReducedMotion } from "@/lib/gsap";

/* ------------------------------------------------------------------ */
/* SplitReveal — masked line-by-line text reveal for display headlines */
/* ------------------------------------------------------------------ */

export function SplitReveal({
  children,
  as: Tag = "h2",
  className,
  delay = 0,
  start = "top 85%",
}: {
  children: ReactNode;
  as?: ElementType;
  className?: string;
  delay?: number;
  start?: string;
}) {
  const ref = useRef<HTMLElement>(null);

  useEffect(() => {
    const el = ref.current;
    if (!el || prefersReducedMotion()) return;

    let split: SplitText | undefined;
    const ctx = gsap.context(() => {
      split = new SplitText(el, { type: "lines", mask: "lines" });
      gsap.from(split.lines, {
        yPercent: 115,
        duration: 1.1,
        stagger: 0.09,
        ease: "power4.out",
        delay,
        scrollTrigger: { trigger: el, start, once: true },
      });
    });

    return () => {
      split?.revert();
      ctx.revert();
    };
  }, [delay, start]);

  return (
    <Tag ref={ref as never} className={className}>
      {children}
    </Tag>
  );
}

/* ------------------------------------------------------- */
/* Reveal — fade-and-rise for blocks, cards, images, copy   */
/* ------------------------------------------------------- */

export function Reveal({
  children,
  as: Tag = "div",
  className,
  delay = 0,
  y = 44,
  start = "top 88%",
}: {
  children: ReactNode;
  as?: ElementType;
  className?: string;
  delay?: number;
  y?: number;
  start?: string;
}) {
  const ref = useRef<HTMLElement>(null);

  useEffect(() => {
    const el = ref.current;
    if (!el || prefersReducedMotion()) return;

    const ctx = gsap.context(() => {
      gsap.from(el, {
        y,
        autoAlpha: 0,
        duration: 1,
        ease: "power3.out",
        delay,
        scrollTrigger: { trigger: el, start, once: true },
      });
    });

    return () => ctx.revert();
  }, [delay, y, start]);

  return (
    <Tag ref={ref as never} className={className}>
      {children}
    </Tag>
  );
}

/* ------------------------------------------------------------- */
/* ScentLine — the brand's 1px gold rule that draws in on scroll  */
/* ------------------------------------------------------------- */

export function ScentLine({ className = "" }: { className?: string }) {
  const ref = useRef<HTMLSpanElement>(null);

  useEffect(() => {
    const el = ref.current;
    if (!el || prefersReducedMotion()) return;

    const ctx = gsap.context(() => {
      gsap.from(el, {
        scaleX: 0,
        duration: 1.4,
        ease: "power4.inOut",
        scrollTrigger: { trigger: el, start: "top 92%", once: true },
      });
    });

    return () => ctx.revert();
  }, []);

  return <span ref={ref} className={`scent-line ${className}`} aria-hidden="true" />;
}
