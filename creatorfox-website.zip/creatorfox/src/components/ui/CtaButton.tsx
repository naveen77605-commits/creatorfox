"use client";

import Link from "next/link";
import { ArrowUpRight } from "lucide-react";
import Magnetic from "@/components/ui/Magnetic";
import { cn } from "@/lib/utils";
import type { ReactNode } from "react";

type Variant = "gold" | "outline" | "outline-light" | "ghost";

const styles: Record<Variant, string> = {
  gold: "bg-gold text-carbon hover:bg-gold-hot",
  outline: "border border-bone/25 text-bone hover:border-gold hover:text-gold",
  "outline-light": "border border-carbon/25 text-carbon hover:border-carbon hover:bg-carbon hover:text-bone",
  ghost: "text-gold hover:text-gold-hot",
};

export default function CtaButton({
  href,
  children,
  variant = "gold",
  className,
  arrow = true,
  magnetic = true,
}: {
  href: string;
  children: ReactNode;
  variant?: Variant;
  className?: string;
  arrow?: boolean;
  magnetic?: boolean;
}) {
  const btn = (
    <Link
      href={href}
      data-cursor
      className={cn(
        "group inline-flex items-center gap-2.5 rounded-full px-7 py-3.5 font-sans text-sm font-bold tracking-wide transition-colors duration-300",
        styles[variant],
        className
      )}
    >
      <span>{children}</span>
      {arrow && (
        <ArrowUpRight
          size={16}
          strokeWidth={2.5}
          className="transition-transform duration-300 ease-out group-hover:translate-x-0.5 group-hover:-translate-y-0.5"
          aria-hidden
        />
      )}
    </Link>
  );

  return magnetic ? <Magnetic>{btn}</Magnetic> : btn;
}
