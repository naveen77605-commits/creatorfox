"use client";

import { useId, useState } from "react";
import { Plus } from "lucide-react";
import { cn } from "@/lib/utils";

/*
 * Accessible animated accordion for FAQs.
 * Height animates via the CSS grid-rows trick — smooth, no JS measuring.
 */
export default function Accordion({
  items,
  light = false,
  className,
}: {
  items: readonly { q: string; a: string }[] | { q: string; a: string }[];
  light?: boolean;
  className?: string;
}) {
  const [open, setOpen] = useState<number | null>(0);
  const baseId = useId();

  return (
    <div className={cn("divide-y", light ? "divide-carbon/10" : "divide-bone/10", className)}>
      {items.map((item, i) => {
        const isOpen = open === i;
        return (
          <div key={item.q}>
            <button
              type="button"
              onClick={() => setOpen(isOpen ? null : i)}
              aria-expanded={isOpen}
              aria-controls={`${baseId}-panel-${i}`}
              id={`${baseId}-button-${i}`}
              data-cursor
              className={cn(
                "flex w-full items-center justify-between gap-6 py-6 text-left transition-colors duration-300",
                light ? "text-carbon hover:text-gold-deep" : "text-bone hover:text-gold"
              )}
            >
              <span className="font-display text-lg font-medium sm:text-xl">{item.q}</span>
              <Plus
                size={20}
                aria-hidden
                className={cn(
                  "shrink-0 transition-transform duration-500 ease-out",
                  isOpen && "rotate-45",
                  light ? "text-gold-deep" : "text-gold"
                )}
              />
            </button>
            <div
              id={`${baseId}-panel-${i}`}
              role="region"
              aria-labelledby={`${baseId}-button-${i}`}
              className="grid transition-[grid-template-rows] duration-500 ease-swift"
              style={{ gridTemplateRows: isOpen ? "1fr" : "0fr" }}
            >
              <div className="overflow-hidden">
                <p
                  className={cn(
                    "max-w-2xl pb-7 text-base leading-relaxed",
                    light ? "text-smoke-dark" : "text-smoke"
                  )}
                >
                  {item.a}
                </p>
              </div>
            </div>
          </div>
        );
      })}
    </div>
  );
}
