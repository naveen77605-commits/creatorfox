"use client";

import type { ReactNode } from "react";
import { cn } from "@/lib/utils";

/*
 * Infinite marquee. Content is duplicated for a seamless loop;
 * duration is controlled via the --marquee-duration CSS variable.
 */
export default function Marquee({
  children,
  duration = 40,
  className,
  reverse = false,
}: {
  children: ReactNode;
  duration?: number;
  className?: string;
  reverse?: boolean;
}) {
  return (
    <div className={cn("group relative flex overflow-hidden", className)}>
      <div
        className="flex w-max shrink-0 animate-marquee items-center [--marquee-duration:40s] motion-reduce:animate-none"
        style={{
          ["--marquee-duration" as string]: `${duration}s`,
          animationDirection: reverse ? "reverse" : "normal",
        }}
      >
        <div className="flex items-center" aria-hidden={false}>
          {children}
        </div>
        <div className="flex items-center" aria-hidden="true">
          {children}
        </div>
      </div>
    </div>
  );
}
