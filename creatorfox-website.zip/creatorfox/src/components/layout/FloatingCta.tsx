"use client";

import { useEffect, useState } from "react";
import { MessageCircle } from "lucide-react";
import { site } from "@/data/site";
import { cn } from "@/lib/utils";

/*
 * Floating WhatsApp CTA — appears after the visitor scrolls past the hero.
 */
export default function FloatingCta() {
  const [visible, setVisible] = useState(false);

  useEffect(() => {
    const onScroll = () => setVisible(window.scrollY > window.innerHeight * 0.8);
    window.addEventListener("scroll", onScroll, { passive: true });
    onScroll();
    return () => window.removeEventListener("scroll", onScroll);
  }, []);

  return (
    <a
      href={site.whatsapp}
      target="_blank"
      rel="noopener noreferrer"
      aria-label="Chat with CreatorFox on WhatsApp"
      data-cursor
      className={cn(
        "fixed bottom-6 right-6 z-[75] flex h-14 w-14 items-center justify-center rounded-full bg-gold text-carbon shadow-[0_10px_40px_-8px_rgba(243,188,9,0.55)] transition-all duration-500 ease-swift hover:scale-110 hover:bg-gold-hot",
        visible ? "translate-y-0 opacity-100" : "pointer-events-none translate-y-16 opacity-0"
      )}
    >
      <MessageCircle size={24} strokeWidth={2.2} aria-hidden />
      <span className="absolute inset-0 -z-10 animate-ping rounded-full bg-gold/40 [animation-duration:2.5s]" aria-hidden />
    </a>
  );
}
