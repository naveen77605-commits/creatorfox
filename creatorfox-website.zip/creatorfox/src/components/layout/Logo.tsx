import { cn } from "@/lib/utils";

/*
 * CreatorFox mark — geometric fox head drawn for this build.
 * Replace the <path> data with your official logo SVG if it differs.
 */
export function FoxMark({ className, title = "CreatorFox" }: { className?: string; title?: string }) {
  return (
    <svg
      viewBox="0 0 48 48"
      role="img"
      aria-label={title}
      className={cn("h-8 w-8", className)}
      fill="currentColor"
    >
      <path d="M5 5l13.5 8L24 9.4 29.5 13 43 5l-3.4 21.4L24 44 8.4 26.4 5 5zm7.2 8.6l1.7 10.6L24 35.8l10.1-11.6 1.7-10.6-7.6 4.5L24 15l-4.2 3.1-7.6-4.5z" />
      <path d="M18.6 24.2l3 3.4-3.9 1.2.9-4.6zM29.4 24.2l.9 4.6-3.9-1.2 3-3.4z" />
    </svg>
  );
}

export function Wordmark({ className }: { className?: string }) {
  return (
    <span className={cn("font-display text-xl font-semibold tracking-tight", className)}>
      Creator<span className="text-gold">Fox</span>
    </span>
  );
}

export default function Logo({ className, light = false }: { className?: string; light?: boolean }) {
  return (
    <span className={cn("inline-flex items-center gap-2.5", className)}>
      <FoxMark className="text-gold" />
      <Wordmark className={light ? "text-carbon" : "text-bone"} />
    </span>
  );
}
