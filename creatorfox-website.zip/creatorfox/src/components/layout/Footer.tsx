import Link from "next/link";
import { ArrowUpRight } from "lucide-react";
import Logo from "@/components/layout/Logo";
import CtaButton from "@/components/ui/CtaButton";
import { ScentLine, SplitReveal } from "@/components/ui/Reveal";
import { services } from "@/data/services";
import { site, offices } from "@/data/site";

const companyLinks = [
  { label: "About", href: "/about" },
  { label: "Case Studies", href: "/case-studies" },
  { label: "Portfolio", href: "/portfolio" },
  { label: "Industries", href: "/industries" },
  { label: "Blog", href: "/blog" },
  { label: "Careers", href: "/careers" },
  { label: "Contact", href: "/contact" },
];

export default function Footer() {
  return (
    <footer className="relative overflow-hidden bg-carbon grain">
      {/* CTA band */}
      <div className="wrap relative z-10 pb-20 pt-24 sm:pt-32">
        <p className="eyebrow mb-6">Next move</p>
        <SplitReveal
          as="p"
          className="max-w-4xl font-display text-display-lg font-medium text-bone"
        >
          Ready to <em className="accent-word">outfox</em> your market?
        </SplitReveal>
        <div className="mt-10 flex flex-wrap items-center gap-4">
          <CtaButton href="/contact">Book a free strategy call</CtaButton>
          <CtaButton href="/case-studies" variant="outline">
            See the proof first
          </CtaButton>
        </div>
        <ScentLine className="mt-20" />
      </div>

      {/* Link columns */}
      <div className="wrap relative z-10 grid grid-cols-2 gap-x-8 gap-y-12 pb-16 md:grid-cols-4">
        <div className="col-span-2 md:col-span-1">
          <Logo />
          <p className="mt-5 max-w-xs text-sm leading-relaxed text-smoke">
            Global digital marketing &amp; web development agency. Bengaluru · Dubai · Sydney ·
            Dortmund.
          </p>
          <div className="mt-6 flex flex-wrap gap-x-5 gap-y-2 text-sm">
            {Object.entries(site.social).map(([name, href]) => (
              <a
                key={name}
                href={href}
                target="_blank"
                rel="noopener noreferrer"
                data-cursor
                className="capitalize text-smoke transition-colors hover:text-gold"
              >
                {name}
              </a>
            ))}
          </div>
        </div>

        <nav aria-label="Footer — services">
          <p className="eyebrow mb-5">Services</p>
          <ul className="grid gap-2.5">
            {services.map((s) => (
              <li key={s.slug}>
                <Link
                  href={`/services/${s.slug}`}
                  className="text-sm text-bone/70 transition-colors hover:text-gold"
                >
                  {s.name}
                </Link>
              </li>
            ))}
          </ul>
        </nav>

        <nav aria-label="Footer — company">
          <p className="eyebrow mb-5">Company</p>
          <ul className="grid gap-2.5">
            {companyLinks.map((l) => (
              <li key={l.href}>
                <Link
                  href={l.href}
                  className="text-sm text-bone/70 transition-colors hover:text-gold"
                >
                  {l.label}
                </Link>
              </li>
            ))}
          </ul>
          <p className="eyebrow mb-4 mt-8">Say hello</p>
          <a href={`mailto:${site.email}`} className="block text-sm text-bone/70 hover:text-gold">
            {site.email}
          </a>
          <a href={`tel:${site.phoneHref}`} className="mt-1.5 block text-sm text-bone/70 hover:text-gold">
            {site.phone}
          </a>
        </nav>

        <div>
          <p className="eyebrow mb-5">Offices</p>
          <ul className="grid gap-5">
            {offices.map((o) => (
              <li key={o.city}>
                <p className="text-sm font-bold text-bone">
                  {o.city}, {o.country}
                </p>
                <p className="mt-1 text-xs leading-relaxed text-smoke">{o.address}</p>
              </li>
            ))}
          </ul>
        </div>
      </div>

      {/* Giant wordmark */}
      <div aria-hidden="true" className="relative z-0 select-none overflow-hidden">
        <p className="wrap -mb-[2.5vw] whitespace-nowrap font-display text-[13.5vw] font-semibold leading-none tracking-tight text-bone/[0.05]">
          CreatorFox<span className="text-gold/20">.</span>
        </p>
      </div>

      {/* Legal bar */}
      <div className="relative z-10 border-t border-bone/10">
        <div className="wrap flex flex-col items-start justify-between gap-3 py-6 text-xs text-smoke sm:flex-row sm:items-center">
          <p>© {new Date().getFullYear()} CreatorFox. All rights reserved.</p>
          <div className="flex items-center gap-6">
            <Link href="/privacy-policy" className="hover:text-gold">
              Privacy Policy
            </Link>
            <Link href="/terms" className="hover:text-gold">
              Terms of Service
            </Link>
            <a
              href={site.whatsapp}
              target="_blank"
              rel="noopener noreferrer"
              className="inline-flex items-center gap-1 hover:text-gold"
            >
              WhatsApp us <ArrowUpRight size={12} aria-hidden />
            </a>
          </div>
        </div>
      </div>
    </footer>
  );
}
