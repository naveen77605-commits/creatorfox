"use client";

import { useEffect, useRef, useState } from "react";
import { gsap, prefersReducedMotion } from "@/lib/gsap";
import { FoxMark } from "@/components/layout/Logo";

/*
 * Loading screen: fox mark + 0→100 counter, then the curtain lifts.
 * Shown once per browser session.
 */
export default function Preloader() {
  const [show, setShow] = useState(false);
  const overlayRef = useRef<HTMLDivElement>(null);
  const countRef = useRef<HTMLSpanElement>(null);

  useEffect(() => {
    if (sessionStorage.getItem("cfx-preloaded") || prefersReducedMotion()) return;
    sessionStorage.setItem("cfx-preloaded", "1");
    setShow(true);
  }, []);

  useEffect(() => {
    if (!show) return;
    const overlay = overlayRef.current;
    const count = countRef.current;
    if (!overlay || !count) return;

    document.body.style.overflow = "hidden";
    const obj = { n: 0 };
    const tl = gsap.timeline({
      onComplete: () => {
        document.body.style.overflow = "";
        setShow(false);
      },
    });

    tl.to(obj, {
      n: 100,
      duration: 1.5,
      ease: "power3.inOut",
      onUpdate: () => {
        count.textContent = String(Math.round(obj.n)).padStart(3, "0");
      },
    })
      .to(overlay.querySelector(".preloader-inner"), { yPercent: -30, autoAlpha: 0, duration: 0.45, ease: "power2.in" })
      .to(overlay, { yPercent: -100, duration: 0.85, ease: "power4.inOut" }, "-=0.1");

    return () => {
      tl.kill();
      document.body.style.overflow = "";
    };
  }, [show]);

  if (!show) return null;

  return (
    <div
      ref={overlayRef}
      aria-hidden="true"
      className="fixed inset-0 z-[130] flex items-center justify-center bg-carbon"
    >
      <div className="preloader-inner flex flex-col items-center gap-6">
        <FoxMark className="h-14 w-14 animate-pulse-soft text-gold" />
        <div className="flex items-baseline gap-2 font-mono text-sm tracking-[0.3em] text-smoke">
          <span ref={countRef} className="text-bone">
            000
          </span>
          <span>/ 100</span>
        </div>
      </div>
    </div>
  );
}
