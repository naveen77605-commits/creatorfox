"use client";

import { useEffect, useRef, useState } from "react";
import Link from "next/link";
import { usePathname } from "next/navigation";
import { ArrowUpRight, ChevronDown, Menu, X } from "lucide-react";
import Logo from "@/components/layout/Logo";
import CtaButton from "@/components/ui/CtaButton";
import { servicesByCategory } from "@/data/services";
import { cn } from "@/lib/utils";

const primaryNav = [
  { label: "Work", href: "/case-studies" },
  { label: "About", href: "/about" },
  { label: "Industries", href: "/industries" },
  { label: "Insights", href: "/blog" },
];

export default function Header() {
  const [scrolled, setScrolled] = useState(false);
  const [hidden, setHidden] = useState(false);
  const [megaOpen, setMegaOpen] = useState(false);
  const [mobileOpen, setMobileOpen] = useState(false);
  const lastY = useRef(0);
  const pathname = usePathname();
  const grouped = servicesByCategory();

  /* close menus on navigation */
  useEffect(() => {
    setMegaOpen(false);
    setMobileOpen(false);
  }, [pathname]);

  /* hide-on-scroll-down, reveal-on-scroll-up */
  useEffect(() => {
    const onScroll = () => {
      const y = window.scrollY;
      setScrolled(y > 24);
      setHidden(y > 140 && y > lastY.current && !megaOpen && !mobileOpen);
      lastY.current = y;
    };
    window.addEventListener("scroll", onScroll, { passive: true });
    return () => window.removeEventListener("scroll", onScroll);
  }, [megaOpen, mobileOpen]);

  /* escape closes overlays */
  useEffect(() => {
    const onKey = (e: KeyboardEvent) => {
      if (e.key === "Escape") {
        setMegaOpen(false);
        setMobileOpen(false);
      }
    };
    window.addEventListener("keydown", onKey);
    return () => window.removeEventListener("keydown", onKey);
  }, []);

  /* lock body scroll while the mobile menu is open */
  useEffect(() => {
    document.body.style.overflow = mobileOpen ? "hidden" : "";
    return () => {
      document.body.style.overflow = "";
    };
  }, [mobileOpen]);

  return (
    <header
      className={cn(
        "fixed inset-x-0 top-0 z-[80] transition-all duration-500 ease-swift",
        hidden ? "-translate-y-full" : "translate-y-0"
      )}
      onMouseLeave={() => setMegaOpen(false)}
    >
      <div
        className={cn(
          "transition-colors duration-500",
          scrolled || megaOpen ? "border-b border-bone/10 bg-carbon/85 backdrop-blur-xl" : "bg-transparent"
        )}
      >
        <div className="wrap flex h-[4.5rem] items-center justify-between lg:h-20">
          <Link href="/" aria-label="CreatorFox — home" data-cursor className="relative z-[85]">
            <Logo />
          </Link>

          {/* Desktop nav */}
          <nav aria-label="Primary" className="hidden items-center gap-1 lg:flex">
            <Link
              href="/case-studies"
              data-cursor
              className="rounded-full px-4 py-2 text-sm font-medium text-bone/80 transition-colors hover:text-gold"
            >
              Work
            </Link>

            <div className="relative" onMouseEnter={() => setMegaOpen(true)}>
              <button
                type="button"
                aria-expanded={megaOpen}
                aria-haspopup="true"
                onClick={() => setMegaOpen((v) => !v)}
                data-cursor
                className={cn(
                  "flex items-center gap-1.5 rounded-full px-4 py-2 text-sm font-medium transition-colors",
                  megaOpen ? "text-gold" : "text-bone/80 hover:text-gold"
                )}
              >
                Services
                <ChevronDown
                  size={14}
                  className={cn("transition-transform duration-300", megaOpen && "rotate-180")}
                  aria-hidden
                />
              </button>
            </div>

            {primaryNav.slice(1).map((item) => (
              <Link
                key={item.href}
                href={item.href}
                data-cursor
                className="rounded-full px-4 py-2 text-sm font-medium text-bone/80 transition-colors hover:text-gold"
              >
                {item.label}
              </Link>
            ))}
          </nav>

          <div className="hidden lg:block">
            <CtaButton href="/contact" className="px-6 py-3">
              Start a project
            </CtaButton>
          </div>

          {/* Mobile toggle */}
          <button
            type="button"
            className="relative z-[85] flex h-11 w-11 items-center justify-center rounded-full border border-bone/15 text-bone lg:hidden"
            aria-expanded={mobileOpen}
            aria-label={mobileOpen ? "Close menu" : "Open menu"}
            onClick={() => setMobileOpen((v) => !v)}
          >
            {mobileOpen ? <X size={20} /> : <Menu size={20} />}
          </button>
        </div>

        {/* Mega menu */}
        <div
          className={cn(
            "hidden overflow-hidden transition-[max-height,opacity] duration-500 ease-swift lg:block",
            megaOpen ? "max-h-[34rem] opacity-100" : "max-h-0 opacity-0"
          )}
        >
          <div className="wrap grid grid-cols-4 gap-10 py-10">
            {grouped.map(({ category, items }) => (
              <div key={category}>
                <p className="eyebrow mb-5">{category}</p>
                <ul className="space-y-1">
                  {items.map((s) => (
                    <li key={s.slug}>
                      <Link
                        href={`/services/${s.slug}`}
                        data-cursor
                        className="group flex items-center justify-between rounded-lg px-3 py-2 -mx-3 text-[0.95rem] text-bone/85 transition-colors hover:bg-bone/5 hover:text-gold"
                      >
                        {s.name}
                        <ArrowUpRight
                          size={13}
                          className="opacity-0 transition-opacity group-hover:opacity-100"
                          aria-hidden
                        />
                      </Link>
                    </li>
                  ))}
                </ul>
              </div>
            ))}
            <div className="flex flex-col justify-between rounded-2xl bg-gradient-to-br from-gold/15 via-gold/5 to-transparent p-6">
              <div>
                <p className="font-display text-xl font-medium text-bone">
                  Not sure where to start?
                </p>
                <p className="mt-2 text-sm leading-relaxed text-smoke">
                  Book a free strategy call. We&apos;ll audit what you have and map the fastest route to growth.
                </p>
              </div>
              <Link
                href="/contact"
                data-cursor
                className="mt-6 inline-flex items-center gap-2 text-sm font-bold text-gold hover:text-gold-hot"
              >
                Book a strategy call <ArrowUpRight size={15} aria-hidden />
              </Link>
            </div>
          </div>
        </div>
      </div>

      {/* Mobile fullscreen menu */}
      <div
        className={cn(
          "fixed inset-0 z-[82] flex flex-col bg-carbon transition-opacity duration-500 lg:hidden",
          mobileOpen ? "opacity-100" : "pointer-events-none opacity-0"
        )}
      >
        <div className="h-[4.5rem]" />
        <nav aria-label="Mobile" className="wrap flex-1 overflow-y-auto pb-10 pt-6">
          <ul className="space-y-2">
            {[{ label: "Home", href: "/" }, ...primaryNav, { label: "Careers", href: "/careers" }, { label: "Contact", href: "/contact" }].map(
              (item, i) => (
                <li
                  key={item.href}
                  className={cn(
                    "border-b border-bone/10 transition-all duration-500",
                    mobileOpen ? "translate-y-0 opacity-100" : "translate-y-4 opacity-0"
                  )}
                  style={{ transitionDelay: `${80 + i * 50}ms` }}
                >
                  <Link
                    href={item.href}
                    className="flex items-center justify-between py-4 font-display text-3xl font-medium text-bone hover:text-gold"
                  >
                    {item.label}
                    <ArrowUpRight size={22} className="text-gold" aria-hidden />
                  </Link>
                </li>
              )
            )}
          </ul>

          <p className="eyebrow mb-4 mt-10">Services</p>
          <ul className="grid grid-cols-2 gap-x-6 gap-y-2.5">
            {grouped.flatMap(({ items }) =>
              items.map((s) => (
                <li key={s.slug}>
                  <Link
                    href={`/services/${s.slug}`}
                    className="text-sm text-bone/75 hover:text-gold"
                  >
                    {s.name}
                  </Link>
                </li>
              ))
            )}
          </ul>

          <div className="mt-10">
            <CtaButton href="/contact" magnetic={false} className="w-full justify-center">
              Start a project
            </CtaButton>
          </div>
        </nav>
      </div>
    </header>
  );
}
