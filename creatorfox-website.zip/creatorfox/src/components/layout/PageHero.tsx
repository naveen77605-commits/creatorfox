import type { ReactNode } from "react";
import { SplitReveal, Reveal, ScentLine } from "@/components/ui/Reveal";

/*
 * Shared inner-page hero: dark, editorial, with the scent line.
 */
export default function PageHero({
  eyebrow,
  title,
  intro,
  children,
}: {
  eyebrow: string;
  title: ReactNode;
  intro?: string;
  children?: ReactNode;
}) {
  return (
    <section className="grain relative overflow-hidden bg-carbon pb-16 pt-40 sm:pb-20 sm:pt-48">
      <div
        className="absolute -right-40 -top-40 h-[34rem] w-[34rem] rounded-full bg-gold/[0.07] blur-[120px]"
        aria-hidden
      />
      <div className="wrap relative z-10">
        <Reveal as="p" className="eyebrow mb-7" y={18}>
          {eyebrow}
        </Reveal>
        <SplitReveal as="h1" className="max-w-4xl font-display text-display-lg font-medium text-bone">
          {title}
        </SplitReveal>
        {intro && (
          <Reveal as="p" className="mt-8 max-w-2xl text-lg leading-relaxed text-smoke" delay={0.15}>
            {intro}
          </Reveal>
        )}
        {children}
        <ScentLine className="mt-16" />
      </div>
    </section>
  );
}
