import PageHero from "@/components/layout/PageHero";
import type { ReactNode } from "react";

export default function LegalPage({
  eyebrow,
  title,
  updated,
  children,
}: {
  eyebrow: string;
  title: ReactNode;
  updated: string;
  children: ReactNode;
}) {
  return (
    <>
      <PageHero eyebrow={eyebrow} title={title} intro={`Last updated: ${updated}`} />
      <section className="bg-bone py-20 text-carbon sm:py-24">
        <div className="wrap">
          <div className="max-w-3xl space-y-10 [&_h2]:font-display [&_h2]:text-2xl [&_h2]:font-medium [&_h2]:text-carbon [&_p]:mt-3 [&_p]:text-base [&_p]:leading-relaxed [&_p]:text-smoke-dark [&_ul]:mt-3 [&_ul]:list-disc [&_ul]:space-y-2 [&_ul]:pl-6 [&_li]:text-base [&_li]:leading-relaxed [&_li]:text-smoke-dark">
            {children}
          </div>
        </div>
      </section>
    </>
  );
}
