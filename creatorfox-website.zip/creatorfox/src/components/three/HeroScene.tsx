"use client";

import { useMemo, useRef } from "react";
import { Canvas, useFrame } from "@react-three/fiber";
import * as THREE from "three";

/*
 * "The Fox Eye" — a golden particle galaxy that slowly rotates and
 * leans toward the cursor. Built as raw buffer geometry: no heavy deps,
 * one draw call, comfortable 60fps on mobile GPUs.
 */

function Galaxy({ count = 6500 }: { count?: number }) {
  const group = useRef<THREE.Group>(null);

  const [positions, colors] = useMemo(() => {
    const pos = new Float32Array(count * 3);
    const col = new Float32Array(count * 3);
    const inside = new THREE.Color("#ffd94a");
    const mid = new THREE.Color("#f3bc09");
    const outside = new THREE.Color("#6b4e00");
    const branches = 4;
    const radiusMax = 3.4;

    for (let i = 0; i < count; i++) {
      const i3 = i * 3;
      const radius = Math.pow(Math.random(), 1.6) * radiusMax;
      const branch = ((i % branches) / branches) * Math.PI * 2;
      const spin = radius * 1.15;

      const rand = () =>
        Math.pow(Math.random(), 3) * (Math.random() < 0.5 ? 1 : -1) * 0.42 * radius * 0.35;

      pos[i3] = Math.cos(branch + spin) * radius + rand();
      pos[i3 + 1] = rand() * 0.7;
      pos[i3 + 2] = Math.sin(branch + spin) * radius + rand();

      const t = radius / radiusMax;
      const c = t < 0.35 ? inside.clone().lerp(mid, t / 0.35) : mid.clone().lerp(outside, (t - 0.35) / 0.65);
      col[i3] = c.r;
      col[i3 + 1] = c.g;
      col[i3 + 2] = c.b;
    }
    return [pos, col];
  }, [count]);

  useFrame((state, delta) => {
    const g = group.current;
    if (!g) return;
    g.rotation.y += delta * 0.055;
    /* lean toward the cursor, softly */
    const targetX = 0.45 + state.pointer.y * 0.12;
    const targetZ = state.pointer.x * 0.08;
    g.rotation.x += (targetX - g.rotation.x) * 0.03;
    g.rotation.z += (targetZ - g.rotation.z) * 0.03;
  });

  return (
    <group ref={group} rotation={[0.45, 0, 0]}>
      <points>
        <bufferGeometry>
          <bufferAttribute attach="attributes-position" args={[positions, 3]} />
          <bufferAttribute attach="attributes-color" args={[colors, 3]} />
        </bufferGeometry>
        <pointsMaterial
          size={0.014}
          sizeAttenuation
          vertexColors
          transparent
          opacity={0.9}
          depthWrite={false}
          blending={THREE.AdditiveBlending}
        />
      </points>
      {/* the pupil — a faint glass sphere at the core */}
      <mesh>
        <sphereGeometry args={[0.32, 32, 32]} />
        <meshBasicMaterial color="#f3bc09" transparent opacity={0.06} />
      </mesh>
    </group>
  );
}

export default function HeroScene({ reduced = false }: { reduced?: boolean }) {
  return (
    <Canvas
      dpr={[1, 1.75]}
      camera={{ position: [0, 1.7, 4.6], fov: 52 }}
      frameloop={reduced ? "demand" : "always"}
      gl={{ antialias: false, alpha: true, powerPreference: "high-performance" }}
      style={{ position: "absolute", inset: 0 }}
      aria-hidden="true"
    >
      <Galaxy count={reduced ? 2500 : 6500} />
    </Canvas>
  );
}
