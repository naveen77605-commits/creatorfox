import type { Metadata } from "next";
import Hero from "@/components/home/Hero";
import TrustMarquee from "@/components/home/TrustMarquee";
import ServicesRail from "@/components/home/ServicesRail";
import Process from "@/components/home/Process";
import CaseStudiesSection from "@/components/home/CaseStudiesSection";
import MetricsBand from "@/components/home/MetricsBand";
import Testimonials from "@/components/home/Testimonials";
import GlobalPresence from "@/components/home/GlobalPresence";
import FaqSection from "@/components/home/FaqSection";
import InsightsStrip from "@/components/home/InsightsStrip";

export const metadata: Metadata = {
  title: "CreatorFox — Global Digital Marketing & Web Development Agency",
  description:
    "Full-service digital agency in Bengaluru, Dubai, Sydney & Dortmund. SEO, Google & Meta Ads, websites, Shopify, branding and AI automation — measured in revenue, not impressions.",
  alternates: { canonical: "/" },
};

export default function HomePage() {
  return (
    <>
      <Hero />
      <TrustMarquee />
      <ServicesRail />
      <Process />
      <CaseStudiesSection />
      <MetricsBand />
      <Testimonials />
      <GlobalPresence />
      <FaqSection />
      <InsightsStrip />
    </>
  );
}
