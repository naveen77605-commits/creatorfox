import type { Metadata } from "next";
import Link from "next/link";
import { notFound } from "next/navigation";
import { ArrowUpRight, Check } from "lucide-react";
import { Reveal, SplitReveal, ScentLine } from "@/components/ui/Reveal";
import CtaButton from "@/components/ui/CtaButton";
import Accordion from "@/components/ui/Accordion";
import Marquee from "@/components/ui/Marquee";
import { getService, services } from "@/data/services";
import { site } from "@/data/site";

type Props = { params: { slug: string } };

export function generateStaticParams() {
  return services.map((s) => ({ slug: s.slug }));
}

export function generateMetadata({ params }: Props): Metadata {
  const s = getService(params.slug);
  if (!s) return {};
  return {
    title: `${s.name} Services — ${s.short}`,
    description: s.intro,
    alternates: { canonical: `/services/${s.slug}` },
    openGraph: {
      title: `${s.name} | CreatorFox`,
      description: s.short,
      url: `${site.url}/services/${s.slug}`,
    },
  };
}

export default function ServicePage({ params }: Props) {
  const s = getService(params.slug);
  if (!s) notFound();

  const related = s.related
    .map((slug) => getService(slug))
    .filter((r): r is NonNullable<typeof r> => Boolean(r));

  const jsonLd = [
    {
      "@context": "https://schema.org",
      "@type": "Service",
      name: s.name,
      description: s.intro,
      provider: { "@type": "Organization", name: "CreatorFox", url: site.url },
      areaServed: ["India", "United Arab Emirates", "Australia", "Germany"],
      url: `${site.url}/services/${s.slug}`,
    },
    {
      "@context": "https://schema.org",
      "@type": "FAQPage",
      mainEntity: s.faqs.map((f) => ({
        "@type": "Question",
        name: f.q,
        acceptedAnswer: { "@type": "Answer", text: f.a },
      })),
    },
    {
      "@context": "https://schema.org",
      "@type": "BreadcrumbList",
      itemListElement: [
        { "@type": "ListItem", position: 1, name: "Home", item: site.url },
        { "@type": "ListItem", position: 2, name: "Services", item: `${site.url}/services` },
        { "@type": "ListItem", position: 3, name: s.name, item: `${site.url}/services/${s.slug}` },
      ],
    },
  ];

  return (
    <>
      <script type="application/ld+json" dangerouslySetInnerHTML={{ __html: JSON.stringify(jsonLd) }} />

      {/* Hero */}
      <section className="grain relative overflow-hidden bg-carbon pb-16 pt-40 sm:pb-24 sm:pt-48">
        <div className="absolute -left-40 top-10 h-[30rem] w-[30rem] rounded-full bg-gold/[0.08] blur-[120px]" aria-hidden />
        <div className="wrap relative z-10">
          <nav aria-label="Breadcrumb" className="mb-8">
            <ol className="flex flex-wrap items-center gap-2 font-mono text-[0.65rem] uppercase tracking-[0.22em] text-smoke">
              <li><Link href="/" className="hover:text-gold">Home</Link></li>
              <li aria-hidden>/</li>
              <li><Link href="/services" className="hover:text-gold">Services</Link></li>
              <li aria-hidden>/</li>
              <li aria-current="page" className="text-gold">{s.name}</li>
            </ol>
          </nav>

          <p className="eyebrow mb-6">{s.category}</p>
          <SplitReveal as="h1" className="max-w-4xl font-display text-display-lg font-medium text-bone">
            {s.headline[0]} <em className="accent-word">{s.headline[1]}</em>
          </SplitReveal>
          <Reveal as="p" className="mt-8 max-w-2xl text-lg leading-relaxed text-smoke" delay={0.15}>
            {s.intro}
          </Reveal>
          <Reveal className="mt-10 flex flex-wrap gap-4" delay={0.25}>
            <CtaButton href="/contact">Get a free {s.name} audit</CtaButton>
            <CtaButton href="/case-studies" variant="outline">See results</CtaButton>
          </Reveal>
          <ScentLine className="mt-16" />
        </div>
      </section>

      {/* Problem */}
      <section className="bg-bone py-24 text-carbon sm:py-28">
        <div className="wrap">
          <p className="eyebrow-light mb-6">The problem</p>
          <SplitReveal as="h2" className="max-w-3xl font-display text-display-sm font-medium">
            {s.problem.title}
          </SplitReveal>
          <div className="mt-12 grid gap-5 md:grid-cols-3">
            {s.problem.points.map((p, i) => (
              <Reveal key={p} delay={0.07 * i}>
                <article className="h-full rounded-3xl bg-white p-8 shadow-[0_20px_50px_-30px_rgba(11,10,7,0.3)]">
                  <span className="font-mono text-xs tracking-[0.25em] text-gold-deep" aria-hidden>
                    {String(i + 1).padStart(2, "0")}
                  </span>
                  <p className="mt-4 text-base leading-relaxed text-smoke-dark">{p}</p>
                </article>
              </Reveal>
            ))}
          </div>
        </div>
      </section>

      {/* Solution + outcomes */}
      <section className="grain relative bg-carbon py-24 sm:py-28">
        <div className="wrap grid gap-14 lg:grid-cols-[1.4fr_1fr]">
          <div>
            <p className="eyebrow mb-6">Our approach</p>
            <SplitReveal as="h2" className="font-display text-display-sm font-medium text-bone">
              How we <em className="accent-word">fix it.</em>
            </SplitReveal>
            <Reveal as="p" className="mt-6 max-w-2xl text-lg leading-relaxed text-smoke" delay={0.1}>
              {s.solution}
            </Reveal>
          </div>
          <div className="grid content-start gap-4">
            {s.outcomes.map((o, i) => (
              <Reveal key={o.label} delay={0.08 * i}>
                <div className="glass rounded-2xl p-6">
                  <p className="font-display text-4xl font-semibold text-gold">{o.value}</p>
                  <p className="mt-2 text-sm leading-snug text-bone/70">{o.label}</p>
                </div>
              </Reveal>
            ))}
            <p className="px-1 text-xs text-smoke">Representative engagement results.</p>
          </div>
        </div>
      </section>

      {/* Benefits */}
      <section className="bg-bone py-24 text-carbon sm:py-28">
        <div className="wrap">
          <p className="eyebrow-light mb-6">What you get</p>
          <SplitReveal as="h2" className="max-w-3xl font-display text-display-sm font-medium">
            Built for outcomes, <em className="accent-word">not activity.</em>
          </SplitReveal>
          <div className="mt-12 grid gap-5 sm:grid-cols-2">
            {s.benefits.map((b, i) => (
              <Reveal key={b.title} delay={0.06 * i}>
                <article className="flex h-full gap-5 rounded-3xl border border-carbon/10 bg-white/60 p-8">
                  <span className="mt-1 flex h-8 w-8 shrink-0 items-center justify-center rounded-full bg-gold/15 text-gold-deep" aria-hidden>
                    <Check size={16} strokeWidth={3} />
                  </span>
                  <div>
                    <h3 className="font-display text-xl font-medium">{b.title}</h3>
                    <p className="mt-2 text-sm leading-relaxed text-smoke-dark">{b.desc}</p>
                  </div>
                </article>
              </Reveal>
            ))}
          </div>
        </div>
      </section>

      {/* Process */}
      <section className="grain relative bg-carbon py-24 sm:py-28">
        <div className="wrap">
          <p className="eyebrow mb-6">The process</p>
          <SplitReveal as="h2" className="max-w-3xl font-display text-display-sm font-medium text-bone">
            Five steps, <em className="accent-word">no surprises.</em>
          </SplitReveal>
          <ol className="mt-14 grid gap-5 md:grid-cols-5">
            {s.process.map((p, i) => (
              <Reveal as="li" key={p.title} delay={0.07 * i} className="list-none">
                <div className="h-full rounded-2xl border border-bone/10 p-6 transition-colors duration-500 hover:border-gold/40">
                  <span className="font-mono text-xs tracking-[0.25em] text-gold" aria-hidden>
                    {String(i + 1).padStart(2, "0")}
                  </span>
                  <h3 className="mt-4 font-display text-lg font-medium text-bone">{p.title}</h3>
                  <p className="mt-2 text-xs leading-relaxed text-smoke">{p.desc}</p>
                </div>
              </Reveal>
            ))}
          </ol>
        </div>
      </section>

      {/* Tools marquee */}
      <section aria-label={`Tools we use for ${s.name}`} className="border-y border-bone/10 bg-coal py-6">
        <Marquee duration={30}>
          {s.tools.map((t) => (
            <span key={t} className="mx-6 flex items-center gap-6 whitespace-nowrap">
              <span className="font-mono text-sm uppercase tracking-[0.2em] text-bone/50">{t}</span>
              <span className="h-1 w-1 rounded-full bg-gold/60" aria-hidden />
            </span>
          ))}
        </Marquee>
      </section>

      {/* FAQs */}
      <section className="bg-bone py-24 text-carbon sm:py-28">
        <div className="wrap grid gap-14 lg:grid-cols-[1fr_1.6fr]">
          <div className="lg:sticky lg:top-32 lg:self-start">
            <p className="eyebrow-light mb-6">FAQs</p>
            <SplitReveal as="h2" className="font-display text-display-sm font-medium">
              {s.name}, <em className="accent-word">explained.</em>
            </SplitReveal>
            <Reveal className="mt-8" delay={0.15}>
              <CtaButton href="/contact" variant="outline-light">Ask something else</CtaButton>
            </Reveal>
          </div>
          <Reveal delay={0.1}>
            <Accordion items={s.faqs} light />
          </Reveal>
        </div>
      </section>

      {/* Related services */}
      <section className="bg-carbon py-24 sm:py-28">
        <div className="wrap">
          <p className="eyebrow mb-6">Pairs well with</p>
          <SplitReveal as="h2" className="max-w-3xl font-display text-display-sm font-medium text-bone">
            Services that <em className="accent-word">multiply</em> this one.
          </SplitReveal>
          <div className="mt-12 grid gap-5 md:grid-cols-3">
            {related.map((r, i) => (
              <Reveal key={r.slug} delay={0.07 * i}>
                <Link
                  href={`/services/${r.slug}`}
                  data-cursor-label="Open"
                  className="group flex h-full flex-col justify-between rounded-3xl border border-bone/10 p-8 transition-colors duration-500 hover:border-gold/40 hover:bg-bone/[0.03]"
                >
                  <div>
                    <p className="eyebrow">{r.category}</p>
                    <h3 className="mt-4 font-display text-2xl font-medium text-bone group-hover:text-gold">
                      {r.name}
                    </h3>
                    <p className="mt-3 text-sm leading-relaxed text-smoke">{r.short}</p>
                  </div>
                  <p className="mt-6 inline-flex items-center gap-2 text-sm font-bold text-gold">
                    Explore
                    <ArrowUpRight size={14} className="transition-transform group-hover:translate-x-0.5 group-hover:-translate-y-0.5" aria-hidden />
                  </p>
                </Link>
              </Reveal>
            ))}
          </div>
        </div>
      </section>
    </>
  );
}
