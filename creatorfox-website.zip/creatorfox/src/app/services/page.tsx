import type { Metadata } from "next";
import Link from "next/link";
import { ArrowUpRight } from "lucide-react";
import PageHero from "@/components/layout/PageHero";
import { Reveal } from "@/components/ui/Reveal";
import CtaButton from "@/components/ui/CtaButton";
import { servicesByCategory } from "@/data/services";

export const metadata: Metadata = {
  title: "Services — SEO, Ads, Web, Branding & AI Automation",
  description:
    "Fourteen in-house disciplines, one accountable team: SEO, Google & Meta Ads, social media, website / WordPress / Shopify development, branding, design, video, content, email and AI automation.",
  alternates: { canonical: "/services" },
};

export default function ServicesPage() {
  const grouped = servicesByCategory();
  let counter = 0;

  return (
    <>
      <PageHero
        eyebrow="Services"
        title={
          <>
            Everything growth needs, <em className="accent-word">under one roof.</em>
          </>
        }
        intro="Fourteen disciplines that usually live at five different vendors. Here they share a desk, a plan and a scoreboard — which is why the work compounds instead of colliding."
      />

      <section className="bg-carbon pb-28">
        <div className="wrap">
          {grouped.map(({ category, items }) => (
            <div key={category} className="pt-16 first:pt-4 sm:pt-20">
              <Reveal as="p" className="eyebrow mb-2" y={16}>
                {category}
              </Reveal>
              <ul className="divide-y divide-bone/10 border-b border-bone/10">
                {items.map((s) => {
                  counter += 1;
                  return (
                    <li key={s.slug}>
                      <Reveal y={24}>
                        <Link
                          href={`/services/${s.slug}`}
                          data-cursor-label="Open"
                          className="group grid items-baseline gap-2 py-7 transition-colors sm:grid-cols-[4rem_1fr_auto] sm:gap-6"
                        >
                          <span className="font-mono text-xs text-smoke transition-colors group-hover:text-gold">
                            {String(counter).padStart(2, "0")}
                          </span>
                          <span>
                            <span className="font-display text-2xl font-medium text-bone transition-colors duration-300 group-hover:text-gold sm:text-4xl">
                              {s.name}
                            </span>
                            <span className="mt-1.5 block max-w-xl text-sm text-smoke">{s.short}</span>
                          </span>
                          <ArrowUpRight
                            size={26}
                            className="hidden text-smoke transition-all duration-300 group-hover:-translate-y-1 group-hover:translate-x-1 group-hover:text-gold sm:block"
                            aria-hidden
                          />
                        </Link>
                      </Reveal>
                    </li>
                  );
                })}
              </ul>
            </div>
          ))}

          <div className="mt-20 flex flex-wrap items-center gap-4">
            <CtaButton href="/contact">Not sure what you need? Ask us</CtaButton>
            <CtaButton href="/case-studies" variant="outline">
              See services in action
            </CtaButton>
          </div>
        </div>
      </section>
    </>
  );
}
