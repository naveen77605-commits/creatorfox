import type { Metadata } from "next";
import PageHero from "@/components/layout/PageHero";
import { Reveal } from "@/components/ui/Reveal";
import CtaButton from "@/components/ui/CtaButton";
import { openRoles, values } from "@/data/content";
import { site } from "@/data/site";
import { ArrowUpRight, MapPin } from "lucide-react";

export const metadata: Metadata = {
  title: "Careers — Join the Skulk",
  description:
    "Work at CreatorFox: open roles in performance marketing, SEO, development, design and content across Bengaluru and remote India. Craft-first, jargon-free, growth-obsessed.",
  alternates: { canonical: "/careers" },
};

export default function CareersPage() {
  return (
    <>
      <PageHero
        eyebrow="Careers"
        title={
          <>
            Do the best work of your <em className="accent-word">career.</em>
          </>
        }
        intro="A skulk is what you call a group of foxes. Ours is a team of strategists, makers and analysts who like shipping real work for real businesses — and can prove it."
      />

      {/* Culture */}
      <section className="bg-bone py-24 text-carbon sm:py-28">
        <div className="wrap">
          <p className="eyebrow-light mb-6">How we work</p>
          <div className="grid gap-5 sm:grid-cols-2 lg:grid-cols-4">
            {values.map((v, i) => (
              <Reveal key={v.title} delay={0.05 * i}>
                <article className="h-full rounded-3xl bg-white p-7 shadow-[0_20px_50px_-30px_rgba(11,10,7,0.25)]">
                  <h2 className="font-display text-lg font-medium text-gold-deep">{v.title}</h2>
                  <p className="mt-3 text-sm leading-relaxed text-smoke-dark">{v.desc}</p>
                </article>
              </Reveal>
            ))}
          </div>
        </div>
      </section>

      {/* Open roles */}
      <section className="bg-carbon py-24 sm:py-28">
        <div className="wrap">
          <p className="eyebrow mb-6">Open roles</p>
          <ul className="divide-y divide-bone/10 border-y border-bone/10">
            {openRoles.map((role, i) => (
              <Reveal as="li" key={role.title} delay={0.04 * i} className="list-none">
                <a
                  href={`mailto:${site.email}?subject=Application: ${encodeURIComponent(role.title)}`}
                  data-cursor-label="Apply"
                  className="group grid gap-3 py-8 sm:grid-cols-[1fr_auto] sm:items-center"
                >
                  <div>
                    <h2 className="font-display text-2xl font-medium text-bone transition-colors group-hover:text-gold sm:text-3xl">
                      {role.title}
                    </h2>
                    <p className="mt-2 max-w-xl text-sm text-smoke">{role.blurb}</p>
                    <p className="mt-3 flex items-center gap-2 text-xs uppercase tracking-[0.2em] text-smoke">
                      <MapPin size={13} className="text-gold" aria-hidden /> {role.location} · {role.type}
                    </p>
                  </div>
                  <span className="inline-flex items-center gap-2 text-sm font-bold text-gold">
                    Apply <ArrowUpRight size={15} aria-hidden />
                  </span>
                </a>
              </Reveal>
            ))}
          </ul>

          <div className="mt-14 rounded-3xl border border-gold/20 bg-gold/[0.05] p-8 sm:p-10">
            <h2 className="font-display text-2xl font-medium text-bone">Don&apos;t see your role?</h2>
            <p className="mt-2 max-w-xl text-sm leading-relaxed text-smoke">
              We hire ahead of openings for exceptional people. Send your portfolio or a note about
              what you'd improve on this very website to{" "}
              <a href={`mailto:${site.email}`} className="font-bold text-gold hover:text-gold-hot">
                {site.email}
              </a>
              .
            </p>
            <div className="mt-6">
              <CtaButton href={`mailto:${site.email}?subject=Open application`} magnetic={false}>
                Introduce yourself
              </CtaButton>
            </div>
          </div>
        </div>
      </section>
    </>
  );
}
