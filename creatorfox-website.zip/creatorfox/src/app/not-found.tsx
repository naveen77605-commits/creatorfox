import type { Metadata } from "next";
import CtaButton from "@/components/ui/CtaButton";
import { FoxMark } from "@/components/layout/Logo";

export const metadata: Metadata = {
  title: "404 — Trail Gone Cold",
  robots: { index: false },
};

export default function NotFound() {
  return (
    <section className="grain relative flex min-h-[100svh] items-center overflow-hidden bg-carbon pt-24">
      <div
        aria-hidden
        className="pointer-events-none absolute inset-0 flex items-center justify-center font-display text-[42vw] font-semibold leading-none text-bone/[0.04]"
      >
        404
      </div>
      <div className="wrap relative z-10 py-24 text-center">
        <FoxMark className="mx-auto h-14 w-14 text-gold/60" />
        <h1 className="mx-auto mt-10 max-w-3xl font-display text-display-md font-medium text-bone">
          This trail went <em className="accent-word">cold.</em>
        </h1>
        <p className="mx-auto mt-5 max-w-md text-base leading-relaxed text-smoke">
          The page you&apos;re after has moved, expired or never existed. Foxes don&apos;t stay lost
          for long — pick a fresh trail.
        </p>
        <div className="mt-10 flex flex-wrap items-center justify-center gap-4">
          <CtaButton href="/">Back to home</CtaButton>
          <CtaButton href="/services" variant="outline">Browse services</CtaButton>
          <CtaButton href="/contact" variant="outline">Talk to us</CtaButton>
        </div>
      </div>
    </section>
  );
}
