import type { Metadata } from "next";
import LegalPage from "@/components/layout/LegalPage";
import { site } from "@/data/site";

export const metadata: Metadata = {
  title: "Privacy Policy",
  description: "How CreatorFox collects, uses and protects your personal information.",
  alternates: { canonical: "/privacy-policy" },
};

export default function PrivacyPolicyPage() {
  return (
    <LegalPage eyebrow="Legal" title="Privacy Policy" updated="July 2026">
      <div>
        <h2>Who we are</h2>
        <p>
          CreatorFox (&quot;we&quot;, &quot;us&quot;) is a digital marketing and web development
          agency headquartered in Bengaluru, India, with offices in Dubai, Sydney and Dortmund.
          This policy explains what personal information we collect through {site.url}, why we
          collect it, and the choices you have.
        </p>
      </div>
      <div>
        <h2>Information we collect</h2>
        <ul>
          <li>
            <strong>Information you give us</strong> — name, email, phone number, company details
            and anything you include in a contact form, email, WhatsApp message or call booking.
          </li>
          <li>
            <strong>Usage information</strong> — pages visited, approximate location, device and
            browser data, collected via analytics cookies when you consent.
          </li>
          <li>
            <strong>Job applications</strong> — CVs, portfolios and related details you submit for
            open roles.
          </li>
        </ul>
      </div>
      <div>
        <h2>How we use it</h2>
        <ul>
          <li>To respond to enquiries and provide proposals you request.</li>
          <li>To deliver and improve services for clients under contract.</li>
          <li>To improve this website's content and performance.</li>
          <li>To send marketing emails you opt into — every email includes an unsubscribe link.</li>
        </ul>
        <p>We never sell your personal information.</p>
      </div>
      <div>
        <h2>Legal bases &amp; international transfers</h2>
        <p>
          We process personal data with consent, to perform a contract, or under legitimate
          interest (such as responding to an enquiry you initiated). Because we operate across
          India, the UAE, Australia and the EU, data may be processed in these regions with
          appropriate safeguards. For EU residents, we honour rights under the GDPR, including
          access, correction, deletion and portability.
        </p>
      </div>
      <div>
        <h2>Cookies &amp; analytics</h2>
        <p>
          We use analytics tools (such as Google Analytics 4) to understand aggregate site usage,
          and advertising cookies only where consented. You can control cookies through your
          browser settings; the site remains fully usable without non-essential cookies.
        </p>
      </div>
      <div>
        <h2>Retention &amp; security</h2>
        <p>
          Enquiry data is kept for as long as needed to serve you and meet legal obligations, then
          deleted. Access is restricted to team members who need it, protected by
          industry-standard technical and organisational measures.
        </p>
      </div>
      <div>
        <h2>Your rights &amp; contact</h2>
        <p>
          To access, correct or delete your data, or to raise any privacy concern, email{" "}
          <a href={`mailto:${site.email}`} className="font-bold underline">
            {site.email}
          </a>{" "}
          with &quot;Privacy&quot; in the subject line. We respond within 30 days.
        </p>
      </div>
    </LegalPage>
  );
}
