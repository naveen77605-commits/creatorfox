import type { Metadata } from "next";
import Link from "next/link";
import PageHero from "@/components/layout/PageHero";
import { Reveal } from "@/components/ui/Reveal";
import CtaButton from "@/components/ui/CtaButton";

export const metadata: Metadata = {
  title: "Portfolio — Selected Projects",
  description:
    "A visual index of CreatorFox work: websites, e-commerce stores, brand identities, campaigns and automation systems built for clients across four countries.",
  alternates: { canonical: "/portfolio" },
};

/*
 * Visual index. Tiles use generative art direction — swap each tile's
 * gradient for real project imagery as approvals come in.
 */
const works = [
  { title: "Skyline Estates", kind: "Website · Google Ads · AI", art: "linear-gradient(135deg,#F3BC09,#8a5a00 45%,#0B0A07)", tall: true },
  { title: "Mira Skincare", kind: "Shopify · Meta Ads · Email", art: "linear-gradient(120deg,#FFD94A,#c2410c 55%,#1a0e02)" },
  { title: "Veda Clinics", kind: "Local SEO · Content", art: "linear-gradient(160deg,#F3BC09,#3a2c00 70%,#0B0A07)" },
  { title: "Hansa Maschinen", kind: "Website · SEO (DE/EN)", art: "linear-gradient(150deg,#e5e7eb,#F3BC09 45%,#0B0A07)", tall: true },
  { title: "Campus One", kind: "Video · Meta Ads · Email", art: "linear-gradient(100deg,#F3BC09,#6d5300 55%,#101010)" },
  { title: "Spice Route", kind: "Branding · Social · GBP", art: "linear-gradient(140deg,#FFD94A,#b45309 50%,#180c00)" },
  { title: "Northwind SaaS", kind: "Content · SEO · Web", art: "linear-gradient(125deg,#F3BC09,#0e7490 60%,#0B0A07)", tall: true },
  { title: "Atlas Fitness", kind: "Brand · Website · Social", art: "linear-gradient(115deg,#FFD94A,#7f1d1d 60%,#0B0A07)" },
];

export default function PortfolioPage() {
  return (
    <>
      <PageHero
        eyebrow="Portfolio"
        title={
          <>
            Work we&apos;d <em className="accent-word">happily</em> sign twice.
          </>
        }
        intro="A cross-section of builds, brands and campaigns. For the numbers behind the visuals, head to the case studies."
      />

      <section className="bg-carbon pb-28">
        <div className="wrap columns-1 gap-5 sm:columns-2 lg:columns-3 [&>*]:mb-5">
          {works.map((w, i) => (
            <Reveal key={w.title} delay={0.04 * i}>
              <Link
                href="/case-studies"
                data-cursor-label="View"
                className={`group relative block overflow-hidden rounded-3xl ${w.tall ? "aspect-[3/4]" : "aspect-[4/3]"}`}
              >
                <div
                  className="absolute inset-0 transition-transform duration-700 ease-out group-hover:scale-105"
                  style={{ background: w.art }}
                  aria-hidden
                />
                <div
                  className="absolute inset-0 opacity-35 mix-blend-overlay"
                  aria-hidden
                  style={{
                    backgroundImage:
                      "radial-gradient(circle at 30% 20%, rgba(255,255,255,0.55), transparent 45%), radial-gradient(circle at 75% 85%, rgba(0,0,0,0.5), transparent 50%)",
                  }}
                />
                <div className="absolute inset-x-0 bottom-0 bg-gradient-to-t from-carbon/90 to-transparent p-7 pt-16">
                  <h2 className="font-display text-2xl font-medium text-bone">{w.title}</h2>
                  <p className="mt-1 text-xs uppercase tracking-[0.2em] text-bone/60">{w.kind}</p>
                </div>
              </Link>
            </Reveal>
          ))}
        </div>

        <div className="wrap mt-16">
          <CtaButton href="/contact">Start your project</CtaButton>
        </div>
      </section>
    </>
  );
}
