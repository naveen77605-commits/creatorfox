import type { Metadata } from "next";
import { Reveal, SplitReveal } from "@/components/ui/Reveal";
import CtaButton from "@/components/ui/CtaButton";
import { FoxMark } from "@/components/layout/Logo";
import { site } from "@/data/site";

export const metadata: Metadata = {
  title: "Thank You — Brief Received",
  description: "Your message is with the CreatorFox team. Expect a reply within one business day.",
  robots: { index: false, follow: true },
};

export default function ThankYouPage() {
  return (
    <section className="grain relative flex min-h-[100svh] items-center overflow-hidden bg-carbon pt-24">
      <div className="absolute left-1/2 top-1/2 h-[40rem] w-[40rem] -translate-x-1/2 -translate-y-1/2 rounded-full bg-gold/[0.07] blur-[130px]" aria-hidden />
      <div className="wrap relative z-10 py-24 text-center">
        <Reveal>
          <FoxMark className="mx-auto h-16 w-16 text-gold" />
        </Reveal>
        <SplitReveal as="h1" className="mx-auto mt-10 max-w-3xl font-display text-display-lg font-medium text-bone">
          The fox has your <em className="accent-word">scent.</em>
        </SplitReveal>
        <Reveal as="p" className="mx-auto mt-6 max-w-xl text-lg leading-relaxed text-smoke" delay={0.15}>
          Your brief is in. A strategist — not a bot — will read it and reply within one business
          day. If it&apos;s urgent, WhatsApp us and we&apos;ll jump on it now.
        </Reveal>
        <Reveal className="mt-10 flex flex-wrap items-center justify-center gap-4" delay={0.25}>
          <CtaButton href={site.whatsapp}>WhatsApp us now</CtaButton>
          <CtaButton href="/case-studies" variant="outline">
            Read case studies while you wait
          </CtaButton>
        </Reveal>
      </div>
    </section>
  );
}
