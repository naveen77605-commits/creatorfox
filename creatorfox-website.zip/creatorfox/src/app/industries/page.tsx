import type { Metadata } from "next";
import PageHero from "@/components/layout/PageHero";
import { Reveal } from "@/components/ui/Reveal";
import CtaButton from "@/components/ui/CtaButton";
import { industries } from "@/data/site";

export const metadata: Metadata = {
  title: "Industries — Sector Playbooks That Work",
  description:
    "CreatorFox grows brands in real estate, healthcare, e-commerce, SaaS, education, hospitality, manufacturing and professional services — with playbooks proven per sector.",
  alternates: { canonical: "/industries" },
};

export default function IndustriesPage() {
  return (
    <>
      <PageHero
        eyebrow="Industries"
        title={
          <>
            Your market has rules. <em className="accent-word">We know them.</em>
          </>
        }
        intro="Generic marketing dies on contact with a real industry. These are the sectors where we've run enough campaigns to know what converts, what's compliant and what's a waste of your budget."
      />

      <section className="bg-carbon pb-28">
        <div className="wrap grid gap-5 sm:grid-cols-2">
          {industries.map((ind, i) => (
            <Reveal key={ind.name} delay={0.05 * i}>
              <article className="group h-full rounded-3xl border border-bone/10 p-8 transition-colors duration-500 hover:border-gold/40 hover:bg-bone/[0.03] sm:p-10">
                <span className="font-mono text-xs tracking-[0.25em] text-gold" aria-hidden>
                  {String(i + 1).padStart(2, "0")}
                </span>
                <h2 className="mt-4 font-display text-2xl font-medium text-bone group-hover:text-gold sm:text-3xl">
                  {ind.name}
                </h2>
                <p className="mt-3 text-sm leading-relaxed text-smoke sm:text-base">{ind.blurb}</p>
              </article>
            </Reveal>
          ))}
        </div>

        <div className="wrap mt-16 flex flex-wrap gap-4">
          <CtaButton href="/contact">Discuss your industry</CtaButton>
          <CtaButton href="/case-studies" variant="outline">See sector results</CtaButton>
        </div>
      </section>
    </>
  );
}
