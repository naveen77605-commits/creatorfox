import type { Metadata } from "next";
import PageHero from "@/components/layout/PageHero";
import { Reveal } from "@/components/ui/Reveal";
import CtaButton from "@/components/ui/CtaButton";
import { blogPosts } from "@/data/content";

export const metadata: Metadata = {
  title: "Blog — Growth Notes from the Field",
  description:
    "Practical writing on SEO, paid media, web development, branding and AI automation — the tactics CreatorFox uses on live client accounts, published.",
  alternates: { canonical: "/blog" },
};

export default function BlogPage() {
  const [featured, ...rest] = blogPosts;

  return (
    <>
      <PageHero
        eyebrow="Insights"
        title={
          <>
            Notes from the <em className="accent-word">hunt.</em>
          </>
        }
        intro="No recycled listicles. Everything here comes from live accounts, real budgets and lessons we paid for so you don't have to."
      />

      <section className="bg-carbon pb-28">
        <div className="wrap">
          {/* featured */}
          <Reveal>
            <article className="group relative overflow-hidden rounded-3xl border border-gold/25 bg-gradient-to-br from-gold/[0.12] via-transparent to-transparent p-8 sm:p-12">
              <div className="flex items-center gap-3 text-xs text-smoke">
                <span className="rounded-full bg-gold px-3 py-1 font-bold text-carbon">Featured</span>
                <span className="rounded-full border border-gold/30 px-3 py-1 text-gold">{featured.category}</span>
                <span>{featured.readTime}</span>
              </div>
              <h2 className="mt-6 max-w-3xl font-display text-display-sm font-medium text-bone group-hover:text-gold">
                {featured.title}
              </h2>
              <p className="mt-4 max-w-2xl text-base leading-relaxed text-smoke">{featured.excerpt}</p>
              <p className="mt-6 font-mono text-xs uppercase tracking-[0.22em] text-smoke">
                {new Date(featured.date).toLocaleDateString("en-GB", { day: "numeric", month: "long", year: "numeric" })}
              </p>
            </article>
          </Reveal>

          {/* grid */}
          <div className="mt-10 grid gap-5 md:grid-cols-2 lg:grid-cols-3">
            {rest.map((post, i) => (
              <Reveal key={post.slug} delay={0.05 * i}>
                <article className="group flex h-full flex-col justify-between rounded-3xl border border-bone/10 p-7 transition-colors duration-500 hover:border-gold/40 hover:bg-bone/[0.03]">
                  <div>
                    <div className="flex items-center gap-3 text-xs text-smoke">
                      <span className="rounded-full border border-gold/30 px-3 py-1 font-medium text-gold">{post.category}</span>
                      <span>{post.readTime}</span>
                    </div>
                    <h2 className="mt-5 font-display text-xl font-medium leading-snug text-bone group-hover:text-gold">
                      {post.title}
                    </h2>
                    <p className="mt-3 text-sm leading-relaxed text-smoke">{post.excerpt}</p>
                  </div>
                  <p className="mt-6 font-mono text-[0.65rem] uppercase tracking-[0.22em] text-smoke">
                    {new Date(post.date).toLocaleDateString("en-GB", { day: "numeric", month: "long", year: "numeric" })}
                  </p>
                </article>
              </Reveal>
            ))}
          </div>

          <div className="mt-16 rounded-3xl border border-bone/10 p-8 sm:flex sm:items-center sm:justify-between sm:p-10">
            <div>
              <h2 className="font-display text-2xl font-medium text-bone">Get the monthly growth letter</h2>
              <p className="mt-2 max-w-md text-sm text-smoke">
                One email a month with what's actually working across our client accounts. No fluff, unsubscribe anytime.
              </p>
            </div>
            <div className="mt-6 sm:mt-0">
              <CtaButton href="/contact">Subscribe via contact</CtaButton>
            </div>
          </div>
        </div>
      </section>
    </>
  );
}
