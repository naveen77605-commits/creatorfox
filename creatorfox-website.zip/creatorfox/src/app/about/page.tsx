import type { Metadata } from "next";
import PageHero from "@/components/layout/PageHero";
import { Reveal, SplitReveal, ScentLine } from "@/components/ui/Reveal";
import CtaButton from "@/components/ui/CtaButton";
import Counter from "@/components/ui/Counter";
import { values, timeline } from "@/data/content";
import { stats } from "@/data/site";

export const metadata: Metadata = {
  title: "About Us — The Team Behind the Fox",
  description:
    "CreatorFox is a global digital marketing and web development agency founded in Bengaluru — now in Dubai, Sydney and Dortmund. Meet the philosophy behind 250+ client wins.",
  alternates: { canonical: "/about" },
};

export default function AboutPage() {
  return (
    <>
      <PageHero
        eyebrow="About CreatorFox"
        title={
          <>
            Sharp minds, <em className="accent-word">sharper</em> instincts.
          </>
        }
        intro="We started in a small Bengaluru studio with one rule: never ship work we wouldn't put our own name on. Eight years, four offices and 250+ brands later, the rule hasn't changed — only the reach has."
      />

      {/* Manifesto */}
      <section className="bg-bone py-24 text-carbon sm:py-32">
        <div className="wrap grid gap-14 lg:grid-cols-2">
          <SplitReveal as="h2" className="font-display text-display-sm font-medium lg:sticky lg:top-32 lg:self-start">
            Why a fox?
          </SplitReveal>
          <div className="space-y-6 text-lg leading-relaxed text-smoke-dark">
            <Reveal as="p">
              Because the fox doesn&apos;t outmuscle anyone. It observes, adapts, and strikes with
              precision — and that&apos;s exactly how growth works when budgets aren&apos;t
              unlimited. Big agencies sell scale. We sell cunning: strategy that finds the gap,
              craft that earns attention, and execution fast enough to use both.
            </Reveal>
            <Reveal as="p" delay={0.1}>
              CreatorFox is deliberately full-stack. Brand, website, content, ads, automation — the
              expensive failures in marketing happen <em>between</em> vendors, so we removed the
              between. One team, one plan, one set of numbers everyone answers to.
            </Reveal>
            <Reveal as="p" delay={0.2}>
              We&apos;re Google-certified, globally distributed and allergic to jargon. If a report
              can&apos;t be understood by the founder who pays for it, we rewrite the report.
            </Reveal>
          </div>
        </div>
      </section>

      {/* Values */}
      <section className="grain relative bg-carbon py-24 sm:py-32">
        <div className="wrap">
          <p className="eyebrow mb-6">What we won&apos;t compromise</p>
          <SplitReveal as="h2" className="max-w-3xl font-display text-display-md font-medium text-bone">
            Four rules, <em className="accent-word">zero</em> exceptions.
          </SplitReveal>
          <div className="mt-14 grid gap-5 sm:grid-cols-2">
            {values.map((v, i) => (
              <Reveal key={v.title} delay={0.06 * i}>
                <article className="h-full rounded-3xl border border-bone/10 p-8 transition-colors duration-500 hover:border-gold/40 sm:p-10">
                  <h3 className="font-display text-2xl font-medium text-gold">{v.title}</h3>
                  <p className="mt-4 text-base leading-relaxed text-smoke">{v.desc}</p>
                </article>
              </Reveal>
            ))}
          </div>
        </div>
      </section>

      {/* Numbers */}
      <section className="bg-gold py-16 text-carbon sm:py-20" aria-label="CreatorFox in numbers">
        <div className="wrap grid grid-cols-2 gap-x-6 gap-y-10 lg:grid-cols-4">
          {stats.map((s, i) => (
            <Reveal key={s.label} delay={0.06 * i}>
              <p className="font-display text-5xl font-semibold tracking-tight sm:text-6xl">
                <Counter value={s.value} suffix={s.suffix} />
              </p>
              <p className="mt-2 max-w-[14rem] text-sm font-medium leading-snug text-carbon/75">{s.label}</p>
            </Reveal>
          ))}
        </div>
      </section>

      {/* Timeline */}
      <section className="bg-bone py-24 text-carbon sm:py-32">
        <div className="wrap">
          <p className="eyebrow-light mb-6">The story so far</p>
          <SplitReveal as="h2" className="max-w-3xl font-display text-display-md font-medium">
            From Yelahanka to <em className="accent-word">everywhere.</em>
          </SplitReveal>
          <ScentLine className="mt-10" />

          <ol className="mt-14 grid gap-x-8 gap-y-12 sm:grid-cols-2 lg:grid-cols-3">
            {timeline.map((t, i) => (
              <Reveal as="li" key={t.year} delay={0.05 * i} className="list-none">
                <p className="font-mono text-sm tracking-[0.25em] text-gold-deep">{t.year}</p>
                <h3 className="mt-3 font-display text-xl font-medium">{t.title}</h3>
                <p className="mt-2 text-sm leading-relaxed text-smoke-dark">{t.desc}</p>
              </Reveal>
            ))}
          </ol>

          <div className="mt-20 flex flex-wrap items-center gap-4">
            <CtaButton href="/careers" variant="outline-light">
              Join the skulk — we&apos;re hiring
            </CtaButton>
            <CtaButton href="/contact">Work with us</CtaButton>
          </div>
        </div>
      </section>
    </>
  );
}
