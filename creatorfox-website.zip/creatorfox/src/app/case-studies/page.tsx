import type { Metadata } from "next";
import PageHero from "@/components/layout/PageHero";
import { Reveal, ScentLine } from "@/components/ui/Reveal";
import CtaButton from "@/components/ui/CtaButton";
import { caseStudies } from "@/data/case-studies";

export const metadata: Metadata = {
  title: "Case Studies — Results, Not Promises",
  description:
    "Real engagements, real numbers: how CreatorFox grows brands across real estate, healthcare, e-commerce, education, manufacturing and hospitality in four countries.",
  alternates: { canonical: "/case-studies" },
};

export default function CaseStudiesPage() {
  return (
    <>
      <PageHero
        eyebrow="Case studies"
        title={
          <>
            The numbers do the <em className="accent-word">talking.</em>
          </>
        }
        intro="Every engagement below started with a problem a founder could feel — leads too expensive, a website that couldn't close, a brand nobody remembered. Here's what happened next."
      />

      <section className="bg-carbon pb-28">
        <div className="wrap space-y-20 sm:space-y-28">
          {caseStudies.map((cs, i) => (
            <article key={cs.slug} className="group">
              <Reveal>
                <div className="grid gap-10 lg:grid-cols-[1fr_1.5fr]">
                  {/* art + client */}
                  <div className="relative min-h-[16rem] overflow-hidden rounded-3xl lg:sticky lg:top-32 lg:self-start">
                    <div
                      className="absolute inset-0 transition-transform duration-700 ease-out group-hover:scale-105"
                      style={{
                        background: `linear-gradient(${cs.art.angle}deg, ${cs.art.from}, ${cs.art.via} 45%, ${cs.art.to})`,
                      }}
                      aria-hidden
                    />
                    <div
                      className="absolute inset-0 opacity-40 mix-blend-overlay"
                      aria-hidden
                      style={{
                        backgroundImage:
                          "radial-gradient(circle at 25% 25%, rgba(255,255,255,0.5), transparent 40%), radial-gradient(circle at 80% 80%, rgba(0,0,0,0.5), transparent 45%)",
                      }}
                    />
                    <div className="relative z-10 flex h-full flex-col justify-between p-8">
                      <p className="font-mono text-[0.65rem] uppercase tracking-[0.25em] text-white/80">
                        {String(i + 1).padStart(2, "0")} — {cs.industry}
                      </p>
                      <p className="font-display text-3xl font-semibold text-white">{cs.client}</p>
                    </div>
                  </div>

                  {/* story */}
                  <div>
                    <h2 className="font-display text-display-sm font-medium text-bone">{cs.headline}</h2>
                    <div className="mt-4 flex flex-wrap gap-2">
                      {cs.services.map((s) => (
                        <span key={s} className="rounded-full border border-bone/15 px-3 py-1 text-xs text-smoke">
                          {s}
                        </span>
                      ))}
                    </div>

                    <div className="mt-8 grid gap-8 sm:grid-cols-2">
                      <div>
                        <p className="eyebrow mb-3">The challenge</p>
                        <p className="text-sm leading-relaxed text-smoke">{cs.challenge}</p>
                      </div>
                      <div>
                        <p className="eyebrow mb-3">What we did</p>
                        <p className="text-sm leading-relaxed text-smoke">{cs.approach}</p>
                      </div>
                    </div>

                    <dl className="mt-10 grid grid-cols-3 gap-4 rounded-2xl border border-gold/20 bg-gold/[0.05] p-6">
                      {cs.metrics.map((m) => (
                        <div key={m.label}>
                          <dt className="sr-only">{m.label}</dt>
                          <dd className="font-display text-2xl font-semibold text-gold sm:text-3xl">{m.value}</dd>
                          <dd className="mt-1 text-xs leading-snug text-smoke">{m.label}</dd>
                        </div>
                      ))}
                    </dl>

                    {cs.quote && (
                      <blockquote className="mt-8 border-l-2 border-gold pl-5">
                        <p className="text-base italic leading-relaxed text-bone/85">“{cs.quote.text}”</p>
                        <cite className="mt-2 block text-xs not-italic text-smoke">— {cs.quote.name}</cite>
                      </blockquote>
                    )}
                  </div>
                </div>
                {i < caseStudies.length - 1 && <ScentLine className="mt-20 sm:mt-28" />}
              </Reveal>
            </article>
          ))}
        </div>

        <div className="wrap mt-24 flex flex-wrap items-center gap-4">
          <CtaButton href="/contact">Become the next case study</CtaButton>
          <CtaButton href="/portfolio" variant="outline">Browse the portfolio</CtaButton>
        </div>
      </section>
    </>
  );
}
