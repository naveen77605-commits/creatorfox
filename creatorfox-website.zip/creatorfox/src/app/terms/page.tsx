import type { Metadata } from "next";
import LegalPage from "@/components/layout/LegalPage";
import { site } from "@/data/site";

export const metadata: Metadata = {
  title: "Terms of Service",
  description: "The terms that govern use of the CreatorFox website and our services.",
  alternates: { canonical: "/terms" },
};

export default function TermsPage() {
  return (
    <LegalPage eyebrow="Legal" title="Terms of Service" updated="July 2026">
      <div>
        <h2>1. Agreement</h2>
        <p>
          By using {site.url} you accept these terms. Client engagements are governed by
          individual proposals and service agreements; where those conflict with this page, the
          signed agreement prevails.
        </p>
      </div>
      <div>
        <h2>2. Website use</h2>
        <p>
          Content on this site is provided for general information about our services. You may not
          scrape, republish or use our content, branding or case study material commercially
          without written permission.
        </p>
      </div>
      <div>
        <h2>3. Proposals &amp; engagements</h2>
        <ul>
          <li>Proposals are valid for 30 days unless stated otherwise.</li>
          <li>Project timelines begin on receipt of the agreed advance and required materials.</li>
          <li>Monthly retainers renew automatically unless terminated with the agreed notice period.</li>
        </ul>
      </div>
      <div>
        <h2>4. Intellectual property</h2>
        <p>
          On full payment, deliverables created specifically for a client transfer to that client.
          We retain rights to our internal tools, frameworks and pre-existing materials, and —
          unless agreed otherwise — the right to showcase completed work in our portfolio.
        </p>
      </div>
      <div>
        <h2>5. Results disclaimer</h2>
        <p>
          Marketing outcomes depend on many factors outside any agency&apos;s control. Metrics
          shown on this website reflect real engagements but do not guarantee equivalent results.
          We commit to transparent reporting, honest forecasting and documented effort — not to
          specific rankings or revenue figures.
        </p>
      </div>
      <div>
        <h2>6. Liability</h2>
        <p>
          To the maximum extent permitted by law, our aggregate liability arising from any
          engagement is limited to the fees paid for the services giving rise to the claim. We are
          not liable for indirect or consequential losses.
        </p>
      </div>
      <div>
        <h2>7. Governing law</h2>
        <p>
          These terms are governed by the laws of India, with courts of Bengaluru, Karnataka
          having jurisdiction. Engagements contracted through our Dubai, Sydney or Dortmund
          entities may specify local governing law in the service agreement.
        </p>
      </div>
      <div>
        <h2>8. Contact</h2>
        <p>
          Questions about these terms: <a href={`mailto:${site.email}`} className="font-bold underline">{site.email}</a>.
        </p>
      </div>
    </LegalPage>
  );
}
