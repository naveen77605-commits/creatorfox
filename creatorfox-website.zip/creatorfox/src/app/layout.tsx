import type { Metadata, Viewport } from "next";
import "./globals.css";
import SmoothScroll from "@/components/providers/SmoothScroll";
import Header from "@/components/layout/Header";
import Footer from "@/components/layout/Footer";
import Preloader from "@/components/layout/Preloader";
import ScrollProgress from "@/components/layout/ScrollProgress";
import FloatingCta from "@/components/layout/FloatingCta";
import Cursor from "@/components/ui/Cursor";
import { site, offices } from "@/data/site";

export const metadata: Metadata = {
  metadataBase: new URL(site.url),
  title: {
    default: "CreatorFox — Global Digital Marketing & Web Development Agency",
    template: "%s | CreatorFox",
  },
  description: site.description,
  keywords: [
    "digital marketing agency",
    "web development company",
    "SEO agency Bangalore",
    "Google Ads agency",
    "Shopify development",
    "branding agency India",
  ],
  openGraph: {
    type: "website",
    siteName: "CreatorFox",
    title: "CreatorFox — Outfox the Market",
    description: site.description,
    url: site.url,
    locale: "en_IN",
  },
  twitter: {
    card: "summary_large_image",
    title: "CreatorFox — Global Digital Marketing & Web Development Agency",
    description: site.description,
  },
  robots: { index: true, follow: true },
  alternates: { canonical: "/" },
};

export const viewport: Viewport = {
  themeColor: "#0B0A07",
  width: "device-width",
  initialScale: 1,
};

const organizationSchema = {
  "@context": "https://schema.org",
  "@type": "Organization",
  name: "CreatorFox",
  url: site.url,
  email: site.email,
  telephone: site.phone,
  slogan: site.tagline,
  description: site.description,
  foundingDate: String(site.founded),
  sameAs: Object.values(site.social),
  address: offices.map((o) => ({
    "@type": "PostalAddress",
    addressLocality: o.city,
    addressCountry: o.country,
    streetAddress: o.address,
  })),
  contactPoint: {
    "@type": "ContactPoint",
    telephone: site.phone,
    contactType: "sales",
    availableLanguage: ["English", "Hindi", "German"],
  },
};

export default function RootLayout({ children }: { children: React.ReactNode }) {
  return (
    <html lang="en">
      <head>
        {/* Premium typefaces: Clash Display (display) + Satoshi (body) via Fontshare */}
        <link rel="preconnect" href="https://api.fontshare.com" crossOrigin="anonymous" />
        <link rel="preconnect" href="https://cdn.fontshare.com" crossOrigin="anonymous" />
        <link
          href="https://api.fontshare.com/v2/css?f[]=clash-display@400,500,600,700&f[]=satoshi@400,500,700,900&display=swap"
          rel="stylesheet"
        />
        <script
          type="application/ld+json"
          dangerouslySetInnerHTML={{ __html: JSON.stringify(organizationSchema) }}
        />
      </head>
      <body>
        <a
          href="#main"
          className="fixed left-4 top-4 z-[140] -translate-y-24 rounded-full bg-gold px-5 py-2.5 text-sm font-bold text-carbon transition-transform focus:translate-y-0"
        >
          Skip to content
        </a>
        <SmoothScroll>
          <Preloader />
          <ScrollProgress />
          <Cursor />
          <Header />
          <main id="main">{children}</main>
          <Footer />
          <FloatingCta />
        </SmoothScroll>
      </body>
    </html>
  );
}
