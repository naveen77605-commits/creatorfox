import type { Metadata } from "next";
import { CalendarDays, Mail, MessageCircle, Phone } from "lucide-react";
import PageHero from "@/components/layout/PageHero";
import { Reveal } from "@/components/ui/Reveal";
import ContactForm from "@/components/contact/ContactForm";
import { site, offices } from "@/data/site";

export const metadata: Metadata = {
  title: "Contact — Book a Free Strategy Call",
  description:
    "Talk to CreatorFox: book a free strategy call, WhatsApp us, or send a brief. Offices in Bengaluru, Dubai, Sydney and Dortmund — reply within one business day.",
  alternates: { canonical: "/contact" },
};

const channels = [
  {
    icon: CalendarDays,
    title: "Book a strategy call",
    desc: "20 minutes, free, no deck. We'll audit what you have live on the call.",
    href: site.calendly,
    label: "Pick a slot",
    external: true,
  },
  {
    icon: MessageCircle,
    title: "WhatsApp",
    desc: "Fastest reply during business hours — usually within minutes.",
    href: site.whatsapp,
    label: "Chat now",
    external: true,
  },
  {
    icon: Mail,
    title: "Email",
    desc: "Send the long version. Attach anything — briefs, audits, ideas.",
    href: `mailto:${site.email}`,
    label: site.email,
    external: false,
  },
  {
    icon: Phone,
    title: "Call",
    desc: "Old school works too. Ask for the growth team.",
    href: `tel:${site.phoneHref}`,
    label: site.phone,
    external: false,
  },
];

export default function ContactPage() {
  return (
    <>
      <PageHero
        eyebrow="Contact"
        title={
          <>
            Let&apos;s plan your <em className="accent-word">next quarter.</em>
          </>
        }
        intro="Tell us where the business is and where it should be. We'll come back with the gaps we see, the fastest route to close them, and a straight number for what it costs."
      />

      <section className="bg-carbon pb-28">
        <div className="wrap grid gap-14 lg:grid-cols-[1.5fr_1fr]">
          {/* form */}
          <Reveal>
            <div className="rounded-3xl border border-bone/10 p-7 sm:p-10">
              <h2 className="mb-8 font-display text-2xl font-medium text-bone">Send a brief</h2>
              <ContactForm />
            </div>
          </Reveal>

          {/* channels + offices */}
          <div className="space-y-4">
            {channels.map((c, i) => (
              <Reveal key={c.title} delay={0.06 * i}>
                <a
                  href={c.href}
                  {...(c.external ? { target: "_blank", rel: "noopener noreferrer" } : {})}
                  data-cursor
                  className="group flex items-start gap-5 rounded-3xl border border-bone/10 p-6 transition-colors duration-500 hover:border-gold/40 hover:bg-bone/[0.03]"
                >
                  <span className="flex h-11 w-11 shrink-0 items-center justify-center rounded-full bg-gold/15 text-gold" aria-hidden>
                    <c.icon size={19} />
                  </span>
                  <span>
                    <span className="block font-display text-lg font-medium text-bone group-hover:text-gold">
                      {c.title}
                    </span>
                    <span className="mt-1 block text-sm leading-relaxed text-smoke">{c.desc}</span>
                    <span className="mt-2 block text-sm font-bold text-gold">{c.label}</span>
                  </span>
                </a>
              </Reveal>
            ))}

            <Reveal delay={0.25}>
              <div className="rounded-3xl border border-bone/10 p-6">
                <p className="eyebrow mb-5">Offices</p>
                <ul className="space-y-4">
                  {offices.map((o) => (
                    <li key={o.city}>
                      <p className="text-sm font-bold text-bone">{o.city}, {o.country}</p>
                      <p className="mt-0.5 text-xs leading-relaxed text-smoke">{o.address}</p>
                    </li>
                  ))}
                </ul>
              </div>
            </Reveal>
          </div>
        </div>
      </section>
    </>
  );
}
