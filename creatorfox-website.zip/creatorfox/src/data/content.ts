export const blogPosts = [
  {
    slug: "seo-in-the-ai-search-era",
    title: "SEO in the AI search era: what still works, what's finished",
    category: "SEO",
    date: "2026-06-18",
    readTime: "9 min",
    excerpt:
      "AI overviews are eating informational clicks. Here's how we're repositioning client content toward decision-stage searches — and why technical trust matters more than ever.",
  },
  {
    slug: "meta-ads-creative-testing-system",
    title: "The creative testing system behind our best Meta accounts",
    category: "Paid Media",
    date: "2026-05-29",
    readTime: "7 min",
    excerpt:
      "Winners aren't found, they're manufactured. The exact hook-angle-format matrix we use to ship 30+ ad tests a quarter without burning budget.",
  },
  {
    slug: "website-redesign-without-losing-rankings",
    title: "How to redesign your website without losing your rankings",
    category: "Web",
    date: "2026-05-12",
    readTime: "8 min",
    excerpt:
      "Most traffic drops after a redesign are self-inflicted. The migration checklist we run on every rebuild — redirects, parity audits and the 30-day watch window.",
  },
  {
    slug: "whatsapp-ai-lead-response",
    title: "Why your lead response time is your real conversion rate",
    category: "AI & Automation",
    date: "2026-04-24",
    readTime: "6 min",
    excerpt:
      "Leads answered in under a minute convert several times better than leads answered in an hour. What we learned deploying WhatsApp AI assistants for sales teams.",
  },
  {
    slug: "brand-systems-beat-logos",
    title: "Stop buying logos. Start building brand systems.",
    category: "Branding",
    date: "2026-04-02",
    readTime: "7 min",
    excerpt:
      "A logo is a mark. A brand system is an operating manual for how your company shows up everywhere. The difference compounds for years.",
  },
  {
    slug: "email-flows-shopify-revenue",
    title: "The five email flows that quietly produce 30% of store revenue",
    category: "E-commerce",
    date: "2026-03-15",
    readTime: "8 min",
    excerpt:
      "Welcome, abandonment, post-purchase, replenishment, win-back. Build these five properly and email becomes your most profitable channel.",
  },
] as const;

export const openRoles = [
  {
    title: "Senior Performance Marketer",
    location: "Bengaluru · Hybrid",
    type: "Full-time",
    blurb: "Own Google and Meta accounts end to end for a portfolio of growth-stage clients. You think in CPA and LTV, not impressions.",
  },
  {
    title: "SEO Strategist",
    location: "Bengaluru · Hybrid",
    type: "Full-time",
    blurb: "Run technical audits, keyword architecture and content programs. You can explain rankings to a founder without jargon.",
  },
  {
    title: "Next.js / WordPress Developer",
    location: "Remote (India)",
    type: "Full-time",
    blurb: "Build fast, accessible, animated websites with pride in the details. GSAP fluency is a big plus.",
  },
  {
    title: "Motion & Brand Designer",
    location: "Bengaluru · Studio",
    type: "Full-time",
    blurb: "Craft identities, social systems and motion work that doesn't look like everyone else's. Portfolio over pedigree.",
  },
  {
    title: "Content Lead — B2B & SaaS",
    location: "Remote (India)",
    type: "Full-time",
    blurb: "Interview experts, write cornerstone content and run editorial calendars that actually influence pipeline.",
  },
] as const;

export const values = [
  {
    title: "Results are the brief",
    desc: "Every deliverable exists to move a business number. If we can't connect the work to leads, revenue or brand equity, we question the work.",
  },
  {
    title: "One team, no gaps",
    desc: "Strategy, design, engineering and media under one roof. The expensive failures in marketing happen between vendors — so we removed the between.",
  },
  {
    title: "Craft is respect",
    desc: "For your customers, your brand and our own names on the work. We sweat details most people never consciously notice — because they feel them anyway.",
  },
  {
    title: "Honest numbers only",
    desc: "Plain-language reports tied to outcomes. If something underperforms, you hear it from us first, with a plan attached.",
  },
] as const;

export const timeline = [
  {
    year: "2018",
    title: "A studio in Yelahanka",
    desc: "CreatorFox starts in Bengaluru as a two-person design and web studio with a stubborn rule: no work we wouldn't put our own name on.",
  },
  {
    year: "2020",
    title: "Full-funnel, by demand",
    desc: "Clients kept asking the same question — 'can you also run the marketing?' SEO and paid media teams join; the agency turns full-service.",
  },
  {
    year: "2022",
    title: "Dubai calling",
    desc: "Our first international clients in the UAE lead to a Dubai presence and a portfolio of D2C and hospitality brands across the Gulf.",
  },
  {
    year: "2023",
    title: "Europe & APAC",
    desc: "Dortmund and Sydney open. Same playbook, new timezones: local presence backed by the Bengaluru engine.",
  },
  {
    year: "2025",
    title: "The AI practice",
    desc: "After a year of internal automation, we productise it: AI assistants, workflow automation and content systems for clients.",
  },
  {
    year: "Today",
    title: "250+ brands later",
    desc: "One team across four offices, still measured the only way that matters — by what our clients' numbers do next quarter.",
  },
] as const;
