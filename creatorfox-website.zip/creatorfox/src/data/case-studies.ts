export type CaseStudy = {
  slug: string;
  client: string;
  industry: string;
  services: string[];
  headline: string;
  challenge: string;
  approach: string;
  metrics: { value: string; label: string }[];
  quote?: { text: string; name: string };
  /* generative art direction for the card — no stock photos */
  art: { from: string; via: string; to: string; angle: number };
};

/*
 * NOTE: client names are anonymised placeholders styled on real engagement
 * patterns. Replace with approved client names, logos and verified numbers
 * before launch — see README "Content to verify".
 */
export const caseStudies: CaseStudy[] = [
  {
    slug: "skyline-estates",
    client: "Skyline Estates",
    industry: "Real Estate — Bengaluru",
    services: ["Google Ads", "Website Development", "AI Automation"],
    headline: "From cold portal leads to a pipeline the sales team trusts",
    challenge:
      "A premium residential developer was spending heavily on property portals: high volumes, terrible quality, six-hour response times. Site visits were flat while cost per booking climbed every quarter.",
    approach:
      "We rebuilt their project landing pages for speed and storytelling, restructured Google Ads around micro-market intent, and deployed a WhatsApp AI assistant that qualified and routed leads in under a minute — day or night.",
    metrics: [
      { value: "−54%", label: "cost per qualified lead" },
      { value: "<60s", label: "lead response time, from 6+ hours" },
      { value: "2.3×", label: "site visits booked per month" },
    ],
    quote: {
      text: "For the first time, marketing and sales are looking at the same numbers — and both are smiling.",
      name: "Marketing head, Skyline Estates",
    },
    art: { from: "#F3BC09", via: "#8a5a00", to: "#0B0A07", angle: 135 },
  },
  {
    slug: "veda-clinics",
    client: "Veda Clinics",
    industry: "Healthcare — Multi-city",
    services: ["SEO", "Google Business Profile", "Content Marketing"],
    headline: "Owning every 'near me' search across 12 neighbourhoods",
    challenge:
      "A growing clinic chain was invisible in local search. Each branch had an unclaimed or inconsistent profile, reviews went unanswered, and the website ranked for nothing patients actually search.",
    approach:
      "Full local SEO program: profiles rebuilt and unified, a review engine at reception desks, condition-level content written with their doctors, and location pages engineered for the map pack.",
    metrics: [
      { value: "+310%", label: "calls from Google Maps" },
      { value: "Top 3", label: "map pack across all 12 locations" },
      { value: "4.8★", label: "average rating, up from 4.1" },
    ],
    quote: {
      text: "Patients now tell us 'I found you on Google and the reviews convinced me.' That sentence pays for the program monthly.",
      name: "Founder, Veda Clinics",
    },
    art: { from: "#FFD94A", via: "#F3BC09", to: "#3a2c00", angle: 160 },
  },
  {
    slug: "mira-skincare",
    client: "Mira Skincare",
    industry: "D2C E-commerce — Dubai",
    services: ["Shopify Development", "Meta Ads", "Email Marketing"],
    headline: "A template store became a brand — and conversion followed",
    challenge:
      "Beautiful products in a forgettable store. A stock Shopify theme, 2.9% cart conversion at checkout stage, ad fatigue on Meta, and an email list of 18,000 earning almost nothing.",
    approach:
      "Custom Shopify theme built around ritual and ingredient storytelling, a monthly Meta creative engine with UGC-style video, and a full Klaviyo lifecycle: welcome, abandonment, replenishment, VIP.",
    metrics: [
      { value: "+87%", label: "store conversion rate" },
      { value: "4.7×", label: "ROAS on Meta at 2× spend" },
      { value: "31%", label: "of revenue now from email flows" },
    ],
    quote: {
      text: "CreatorFox runs our store, our ads and our email as one system. Growth stopped feeling like luck.",
      name: "Co-founder, Mira Skincare",
    },
    art: { from: "#F3BC09", via: "#c2410c", to: "#1a0e02", angle: 120 },
  },
  {
    slug: "hansa-machinen",
    client: "Hansa Maschinen",
    industry: "B2B Manufacturing — Germany",
    services: ["Website Development", "SEO", "Content Marketing"],
    headline: "An industrial catalogue turned into a lead-generating asset",
    challenge:
      "A Dortmund machinery manufacturer had deep engineering credibility and a website that hid it — no English version, no product data online, zero inbound enquiries.",
    approach:
      "Bilingual rebuild with a structured product catalogue, technical SEO for high-value machine categories, and engineer-interview content that answers the questions buyers ask before an RFQ.",
    metrics: [
      { value: "+92%", label: "enquiry form conversions" },
      { value: "38", label: "commercial keywords on page one (DE + EN)" },
      { value: "5", label: "export markets generating inbound RFQs" },
    ],
    art: { from: "#e5e7eb", via: "#F3BC09", to: "#0B0A07", angle: 150 },
  },
  {
    slug: "campus-one",
    client: "Campus One",
    industry: "Education — Australia",
    services: ["Meta Ads", "Video Marketing", "Email Marketing"],
    headline: "Admissions season, engineered end to end",
    challenge:
      "A Sydney education provider relied on expensive aggregator leads. Enrolment costs were rising and the brand had no direct pipeline of its own.",
    approach:
      "Student-story video production, full-funnel Meta campaigns by course intent, and a nurture email journey from first click to enrolment — with counsellor handoff automated at the right moment.",
    metrics: [
      { value: "−63%", label: "cost per qualified lead" },
      { value: "3.4×", label: "video watch-through vs. previous creative" },
      { value: "+41%", label: "direct (non-aggregator) enrolments" },
    ],
    art: { from: "#F3BC09", via: "#6d5300", to: "#101010", angle: 100 },
  },
  {
    slug: "spice-route",
    client: "Spice Route Hospitality",
    industry: "Hospitality — India & UAE",
    services: ["Social Media Marketing", "Branding", "Google Business Profile"],
    headline: "A restaurant group people follow before they've even visited",
    challenge:
      "Six outlets, six inconsistent identities, feeds full of flyer-style posts. Footfall depended entirely on aggregator apps and their commissions.",
    approach:
      "Unified brand system across outlets, a food-first content engine with monthly shoot days, influencer collaborations, and Google profiles tuned for 'near me' discovery in every neighbourhood.",
    metrics: [
      { value: "120k+", label: "organic followers built across platforms" },
      { value: "+38%", label: "direct reservations vs. aggregator orders" },
      { value: "5×", label: "review velocity across outlets" },
    ],
    art: { from: "#FFD94A", via: "#b45309", to: "#180c00", angle: 140 },
  },
];
