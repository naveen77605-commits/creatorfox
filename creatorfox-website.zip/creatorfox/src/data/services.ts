export type Service = {
  slug: string;
  name: string;
  category: "Performance & Growth" | "Web & Technology" | "Brand & Content";
  short: string; // one-liner for menus and cards
  headline: [string, string]; // [plain part, gold italic accent part]
  intro: string;
  problem: { title: string; points: string[] };
  solution: string;
  benefits: { title: string; desc: string }[];
  process: { title: string; desc: string }[];
  outcomes: { value: string; label: string }[]; // representative results
  tools: string[];
  faqs: { q: string; a: string }[];
  related: string[];
};

export const serviceCategories = [
  "Performance & Growth",
  "Web & Technology",
  "Brand & Content",
] as const;

export const services: Service[] = [
  /* ----------------------------- PERFORMANCE ----------------------------- */
  {
    slug: "seo",
    name: "SEO",
    category: "Performance & Growth",
    short: "Own the search results your customers actually type.",
    headline: ["Be found first,", "not eventually."],
    intro:
      "Search is where intent lives. Our SEO programs combine technical foundations, content built around real buyer questions, and authority earned the durable way — so you rank for searches that produce revenue, not just traffic.",
    problem: {
      title: "Ranking nowhere is expensive. Ranking for the wrong things is worse.",
      points: [
        "Your competitors appear for every high-intent search in your market — you appear on page three, if at all.",
        "Past agencies chased vanity keywords and sent traffic that never converted into enquiries or orders.",
        "Your site has technical debt — slow pages, broken structure, thin content — quietly capping everything else you spend on marketing.",
      ],
    },
    solution:
      "We run SEO as a revenue channel, not a checklist. Every engagement starts with a forensic audit and a keyword map tied to your actual sales conversations. Then we fix the technical layer, build content that answers what buyers ask before they buy, and earn links from places your industry respects. You see rankings, traffic and — most importantly — leads, in one monthly report.",
    benefits: [
      {
        title: "Revenue-mapped keywords",
        desc: "We target searches your buyers make at decision time, prioritised by business value — not search volume bragging rights.",
      },
      {
        title: "Technical foundations",
        desc: "Core Web Vitals, crawlability, structured data and site architecture handled by the same team that builds websites for a living.",
      },
      {
        title: "Content that converts",
        desc: "Landing pages, comparison pages and guides written to rank and to persuade — every page has a job in the funnel.",
      },
      {
        title: "Compounding returns",
        desc: "Unlike paid media, rankings don't reset to zero when the invoice stops. SEO becomes the cheapest lead source you own.",
      },
    ],
    process: [
      { title: "Forensic audit", desc: "Technical crawl, content inventory, backlink profile and competitor gap analysis — you see exactly where you stand." },
      { title: "Keyword & content map", desc: "Every target keyword mapped to a page, a buyer stage and a business outcome." },
      { title: "Technical sprint", desc: "Speed, indexation, schema and architecture fixes shipped in the first 30 days." },
      { title: "Content & authority", desc: "Monthly publishing and digital PR that earns links, mentions and topical authority." },
      { title: "Measure & compound", desc: "Monthly reporting on rankings, traffic and leads; strategy re-weighted toward what's winning." },
    ],
    outcomes: [
      { value: "3.2×", label: "organic traffic growth in 9 months for a Bengaluru real-estate developer" },
      { value: "#1–3", label: "positions for 40+ commercial keywords for a healthcare group" },
      { value: "−58%", label: "cost per lead vs. paid channels once organic matured" },
    ],
    tools: ["Google Search Console", "Ahrefs", "Semrush", "Screaming Frog", "GA4", "Looker Studio"],
    faqs: [
      { q: "How long until SEO shows results?", a: "Technical fixes often move things within weeks; meaningful ranking and lead growth typically shows in 3–6 months. We set milestone expectations in the first proposal so progress is measurable from month one." },
      { q: "Do you guarantee #1 rankings?", a: "No honest agency can. We guarantee process, transparency and effort against a agreed keyword map — and we show you the movement every month." },
      { q: "Do you write the content yourselves?", a: "Yes. Our in-house content team writes it, our SEO leads brief it, and you approve everything before it goes live." },
      { q: "We were hit by a Google update. Can you help?", a: "Recovery audits are one of our most common starting points. We diagnose whether it's content quality, links or technical trust, then rebuild systematically." },
    ],
    related: ["content-marketing", "google-ads", "website-development"],
  },
  {
    slug: "google-ads",
    name: "Google Ads",
    category: "Performance & Growth",
    short: "Capture demand the moment it's searched.",
    headline: ["Every rupee of spend,", "accounted for."],
    intro:
      "Google Ads puts you in front of buyers at the exact moment of intent — if the account is built right. We plan, build and manage Search, Performance Max, Shopping and YouTube campaigns with one obsession: cost per acquisition you can scale profitably.",
    problem: {
      title: "Most ad accounts leak money silently.",
      points: [
        "Broad keywords, lazy match types and no negative lists — you pay for clicks that could never become customers.",
        "Conversion tracking is broken or half-set-up, so budget decisions are guesses dressed as data.",
        "Landing pages don't match the ads, so even good clicks bounce before they convert.",
      ],
    },
    solution:
      "We rebuild from the measurement up. First, airtight conversion tracking so every lead and sale is attributed. Then tightly-themed campaigns with intent-matched landing pages, systematic search-term hygiene and weekly optimisation. As a Google-certified partner team, we manage the account as if the spend were our own — because our retention depends on your ROI.",
    benefits: [
      { title: "Tracking you can trust", desc: "GA4, server-side tagging and offline conversion imports — so the account optimises toward real revenue, not form-fills that go nowhere." },
      { title: "Full-funnel coverage", desc: "Search for intent, Performance Max and Shopping for scale, YouTube and Display for demand creation — sequenced deliberately." },
      { title: "Landing pages included", desc: "Our developers and designers build the pages your ads deserve. Message match is where Quality Scores and conversion rates are won." },
      { title: "Weekly optimisation cadence", desc: "Search-term audits, bid strategy reviews, creative rotation and budget re-weighting — every single week, documented." },
    ],
    process: [
      { title: "Account & tracking audit", desc: "We find the leaks: wasted spend, broken attribution, missed intent. You get the findings whether or not you hire us." },
      { title: "Structure & build", desc: "Campaigns rebuilt around buyer intent themes with negative lists, ad assets and experiments planned in." },
      { title: "Landing page sprint", desc: "Dedicated pages for top campaigns, built to load fast and convert." },
      { title: "Launch & stabilise", desc: "Two to four weeks of controlled spend while smart bidding learns on clean data." },
      { title: "Scale what works", desc: "Budget flows to winning segments; monthly reports connect spend to pipeline and revenue." },
    ],
    outcomes: [
      { value: "−54%", label: "cost per lead in 90 days for a real-estate client after account rebuild" },
      { value: "4.7×", label: "ROAS on Shopping for a D2C brand within two quarters" },
      { value: "212%", label: "more qualified demo bookings for a SaaS firm at flat spend" },
    ],
    tools: ["Google Ads", "GA4", "Google Tag Manager", "Looker Studio", "CallRail", "Hotjar"],
    faqs: [
      { q: "What budget do we need to start?", a: "Enough for statistical signal in your market — typically ₹75k–₹3L+/month in India, or the equivalent abroad. On the strategy call we'll tell you honestly whether your budget can win in your category." },
      { q: "How is your fee structured?", a: "A flat monthly management fee scoped to account complexity — not a percentage that rewards us for spending more of your money." },
      { q: "Who owns the ad account?", a: "You do, always. We work inside your account, and everything we build stays with you if we ever part ways." },
      { q: "How fast will we see results?", a: "Ads generate data immediately. Expect meaningful CPA trends within 4–6 weeks once tracking is clean and learning phases complete." },
    ],
    related: ["meta-ads", "seo", "website-development"],
  },
  {
    slug: "meta-ads",
    name: "Meta Ads",
    category: "Performance & Growth",
    short: "Facebook & Instagram campaigns that create demand, not just clicks.",
    headline: ["Stop the scroll.", "Start the pipeline."],
    intro:
      "On Meta, creative is the targeting. We pair performance media buying with thumb-stopping ad creative — produced in-house — to build full-funnel Facebook and Instagram campaigns that turn cold audiences into customers.",
    problem: {
      title: "Boosted posts are not a strategy.",
      points: [
        "Ad fatigue sets in fast and your account has no creative pipeline to answer it — the same three ads run for months.",
        "Campaigns optimise for clicks and reach while the business needs leads and sales.",
        "iOS-era signal loss means your account is optimising on incomplete data and nobody has fixed the measurement.",
      ],
    },
    solution:
      "We run Meta as a creative-volume game with a measurement backbone. Conversions API and pixel are configured properly, audiences are structured broad-to-narrow, and our design and video team ships fresh ad concepts every month — hooks, UGC-style videos, statics, carousels — tested systematically so winners scale and losers die fast.",
    benefits: [
      { title: "In-house ad creative", desc: "Scripts, shoots, edits and statics from our own studio. No waiting on your side for assets — we produce the volume testing demands." },
      { title: "Signal-proof measurement", desc: "Conversions API, event deduplication and UTM discipline so the algorithm learns from real outcomes." },
      { title: "Full-funnel structure", desc: "Cold prospecting, warm retargeting and retention audiences with distinct creative and metrics for each stage." },
      { title: "Systematic creative testing", desc: "Every ad is a hypothesis. We log hooks, formats and angles so learning compounds month over month." },
    ],
    process: [
      { title: "Account & pixel audit", desc: "Measurement, structure and creative history reviewed; wasted spend identified." },
      { title: "Creative strategy", desc: "Customer research turned into hooks and angles; first month's creative slate produced." },
      { title: "Rebuild & launch", desc: "Clean campaign structure with CAPI tracking and clear naming conventions." },
      { title: "Test & iterate", desc: "Weekly creative rotations and audience experiments with documented learnings." },
      { title: "Scale winners", desc: "Budget consolidates into proven ads and audiences; new concepts keep the pipeline fresh." },
    ],
    outcomes: [
      { value: "2.1×", label: "blended ROAS improvement for a Dubai D2C brand in one quarter" },
      { value: "−63%", label: "cost per qualified lead for an education client" },
      { value: "38", label: "new ad creatives tested in the first 90 days of a typical engagement" },
    ],
    tools: ["Meta Ads Manager", "Conversions API", "GA4", "Motion", "Figma", "CapCut / Premiere"],
    faqs: [
      { q: "Do Meta ads still work after iOS privacy changes?", a: "Yes — for accounts with proper Conversions API setup and strong creative. Signal loss killed lazy accounts, not the channel." },
      { q: "Do you produce the ad creative?", a: "Yes, it's included. Statics, carousels and video edits come from our studio; where a product shoot is needed, we script and direct it." },
      { q: "B2B or B2C?", a: "Both. B2C and D2C see the fastest feedback loops, but we run lead-gen for B2B, education, healthcare and real estate on Meta every day." },
      { q: "What's the minimum budget?", a: "We usually recommend at least ₹60k–₹1.5L/month media spend (or equivalent) so creative testing gets enough data to be meaningful." },
    ],
    related: ["google-ads", "social-media-marketing", "video-marketing"],
  },
  {
    slug: "social-media-marketing",
    name: "Social Media Marketing",
    category: "Performance & Growth",
    short: "Feeds people follow, content people share, communities that convert.",
    headline: ["Make your brand", "worth following."],
    intro:
      "Social media is your brand's daily presence in your customer's life. We handle strategy, content production, publishing, community and growth across Instagram, LinkedIn, Facebook and YouTube — with content good enough that people would follow you even if they weren't buying.",
    problem: {
      title: "Posting consistently isn't the same as growing.",
      points: [
        "Your feed is active but generic — it could belong to any company in your category.",
        "Content is created ad-hoc with no strategy, so nothing compounds and every month starts from zero.",
        "Engagement never becomes enquiries because there's no path from content to conversion.",
      ],
    },
    solution:
      "We build a content system, not a posting schedule. It starts with positioning: what your brand should be known for, said in a voice only you can use. From there, monthly content calendars mix authority content, culture, product and proof — produced by our in-house designers, writers and video editors — with community management and monthly analytics that tie growth to business results.",
    benefits: [
      { title: "A recognisable voice", desc: "Strategy first: pillars, tone and visual language that make your content unmistakably yours." },
      { title: "Full production in-house", desc: "Design, copy, short-form video and motion graphics from one team — consistent quality, no vendor juggling." },
      { title: "Platform-native thinking", desc: "Reels behave like Reels, LinkedIn posts read like LinkedIn — not one asset lazily cross-posted everywhere." },
      { title: "Growth tied to funnel", desc: "Bios, DMs, lead magnets and offers engineered so followers have somewhere to go." },
    ],
    process: [
      { title: "Brand & audience deep-dive", desc: "Competitor scan, audience research and voice definition." },
      { title: "Content strategy", desc: "Pillars, formats, cadence and platform mix agreed with you." },
      { title: "Production sprints", desc: "Batched monthly shoots and design sprints keep quality high and costs sane." },
      { title: "Publish & engage", desc: "Scheduling, community management and social listening handled daily." },
      { title: "Review & sharpen", desc: "Monthly analytics reviews double down on formats your audience proves it wants." },
    ],
    outcomes: [
      { value: "5.4×", label: "average engagement-rate growth across managed accounts in year one" },
      { value: "120k+", label: "organic followers built for a hospitality group across platforms" },
      { value: "31%", label: "of one clinic's new patient enquiries now start on Instagram" },
    ],
    tools: ["Meta Business Suite", "Buffer / Later", "Figma", "CapCut", "Notion", "Metricool"],
    faqs: [
      { q: "Which platforms should we be on?", a: "The ones where your buyers spend time — usually two done well beats five done half-heartedly. We'll recommend a mix in the strategy phase and say no to platforms that won't pay off." },
      { q: "Do you shoot original content?", a: "Yes. Monthly content shoots (on-site or in-studio) are part of most retainers, supplemented with motion design and brand-fitted templates." },
      { q: "Who replies to comments and DMs?", a: "We do, within agreed response windows and an escalation playbook for anything sensitive. You stay in the loop without living in the inbox." },
      { q: "How do you measure success?", a: "Reach and engagement as leading indicators; profile visits, link clicks, DMs and attributed enquiries as the numbers that matter." },
    ],
    related: ["meta-ads", "video-marketing", "content-marketing"],
  },
  {
    slug: "google-business-profile",
    name: "Google Business Profile",
    category: "Performance & Growth",
    short: "Win the map pack and turn local searches into walk-ins and calls.",
    headline: ["Own your", "neighbourhood."],
    intro:
      "For local businesses, the Google map pack is the highest-intent real estate on the internet. We optimise, manage and defend your Google Business Profile so nearby customers find you first — and what they find convinces them.",
    problem: {
      title: "Local customers are searching. Someone else is answering.",
      points: [
        "Your profile is incomplete, inconsistent or duplicated — and Google quietly ranks you below competitors because of it.",
        "Reviews arrive unmanaged: negatives sit unanswered at the top, and happy customers are never asked.",
        "Photos, posts and Q&A are stale, signalling to both Google and customers that nobody's home.",
      ],
    },
    solution:
      "We treat your profile like a storefront. Complete optimisation of categories, services, attributes and NAP consistency; a review generation and response system that compounds your reputation; weekly posts and fresh photography; and local citation building that strengthens the whole local signal. Then we track calls, direction requests and bookings so you see exactly what local search delivers.",
    benefits: [
      { title: "Map-pack visibility", desc: "Systematic optimisation of every ranking factor Google's local algorithm actually weighs." },
      { title: "Review engine", desc: "Automated, polite review requests at the right moment — plus professional responses to every review, good or bad." },
      { title: "Always-fresh presence", desc: "Weekly posts, offers, photos and Q&A management keep the profile alive and converting." },
      { title: "Multi-location ready", desc: "Consistent management across branches with per-location reporting — built for clinics, showrooms and franchises." },
    ],
    process: [
      { title: "Local audit", desc: "Profile health, citation consistency, review standing and competitor benchmark." },
      { title: "Optimisation sprint", desc: "Every field, category, service and attribute completed and keyword-aligned." },
      { title: "Review system setup", desc: "Request flows via SMS/WhatsApp/QR plus response templates in your voice." },
      { title: "Ongoing management", desc: "Posts, photos, Q&A and spam-listing takedowns handled weekly." },
      { title: "Local reporting", desc: "Calls, directions, website clicks and ranking grid reports monthly." },
    ],
    outcomes: [
      { value: "+310%", label: "monthly calls from Maps for a dental clinic in 6 months" },
      { value: "4.8★", label: "average rating built from 4.1 for a restaurant group, with 5× review velocity" },
      { value: "Top 3", label: "map-pack placement for a showroom across 12 tracked neighbourhoods" },
    ],
    tools: ["Google Business Profile", "BrightLocal", "Whitespark", "GatherUp", "CallRail"],
    faqs: [
      { q: "Is this the same as SEO?", a: "It's the local layer of it. GBP management wins the map pack; our SEO service wins the organic results below it. Together they dominate the local page." },
      { q: "Can you remove fake or unfair reviews?", a: "We flag policy-violating reviews through Google's process and draft responses that protect your reputation while removal is pending. Legitimate negatives we help you answer well." },
      { q: "We have multiple branches — can you manage all of them?", a: "Yes, multi-location management with location pages, consistent data and per-branch reporting is one of our specialities." },
      { q: "How quickly does local visibility improve?", a: "Profile fixes show impact within weeks; competitive map-pack rankings typically firm up over 2–4 months as reviews and citations build." },
    ],
    related: ["seo", "google-ads", "social-media-marketing"],
  },

  /* --------------------------- WEB & TECHNOLOGY --------------------------- */
  {
    slug: "website-development",
    name: "Website Development",
    category: "Web & Technology",
    short: "Custom websites engineered to persuade — fast, beautiful, built to rank.",
    headline: ["Websites that work", "as hard as you do."],
    intro:
      "Your website is your hardest-working salesperson — or your most expensive brochure. We design and build custom websites that load instantly, rank on Google, tell your story with craft, and convert visitors into enquiries.",
    problem: {
      title: "A pretty website that doesn't sell is just decoration.",
      points: [
        "Your current site is slow, dated or template-built — and visitors judge your business by it in under three seconds.",
        "It wasn't built for SEO or conversion, so marketing spend lands on a page that can't close.",
        "Every small change needs a developer, so the site drifts further out of date each month.",
      ],
    },
    solution:
      "We run design and engineering as one team. Strategy and wireframes rooted in your sales process; interface design with real craft; then a build on modern frameworks (Next.js/React) or a CMS you can edit yourself — with performance budgets, on-page SEO and analytics wired in from day one. Launch includes training, documentation and a care plan, so the site keeps earning long after go-live.",
    benefits: [
      { title: "Conversion-first design", desc: "Information architecture and page flows built around how your customers actually decide — not around a template's sections." },
      { title: "Speed as a feature", desc: "Core Web Vitals green by design: optimised images, code-splitting, edge delivery. Fast sites rank better and convert better." },
      { title: "SEO built in, not bolted on", desc: "Semantic structure, schema markup, clean URLs and content guidance included in every build." },
      { title: "Yours to grow", desc: "Editable CMS, component libraries and documentation. No lock-in, no ransom for your own website." },
    ],
    process: [
      { title: "Discovery & strategy", desc: "Goals, audiences, content audit and sitemap. We agree what the site must achieve before pixels move." },
      { title: "UX & wireframes", desc: "Page-by-page structure and copy direction, tested against real user journeys." },
      { title: "Design", desc: "A visual language crafted for your brand — reviewed with you at every milestone." },
      { title: "Build & QA", desc: "Development, content entry, accessibility and device testing, performance tuning." },
      { title: "Launch & care", desc: "Deployment, redirects, analytics, training — and an optional care plan for updates and iteration." },
    ],
    outcomes: [
      { value: "0.9s", label: "median load time across our recent launches" },
      { value: "+92%", label: "enquiry-form conversions after a B2B manufacturer's rebuild" },
      { value: "95+", label: "Lighthouse performance scores as our launch standard" },
    ],
    tools: ["Next.js", "React", "Tailwind CSS", "WordPress", "Figma", "Vercel", "GSAP"],
    faqs: [
      { q: "How long does a website take?", a: "Marketing sites typically run 4–8 weeks; larger custom builds 8–14. We fix the timeline in the proposal and hold ourselves to milestones you can see." },
      { q: "Will we be able to edit it ourselves?", a: "Yes. Whether it's a headless CMS or WordPress, you get an editing experience your team can use without touching code — plus training and documentation." },
      { q: "What does a website cost?", a: "Fixed-price, scoped to pages, features and integrations. After the strategy call you'll get a detailed proposal — no hourly surprises." },
      { q: "Do you handle hosting and maintenance?", a: "We set up fast, secure hosting in your name and offer care plans covering updates, backups, monitoring and small improvements." },
    ],
    related: ["wordpress-development", "shopify-development", "seo"],
  },
  {
    slug: "wordpress-development",
    name: "WordPress Development",
    category: "Web & Technology",
    short: "Custom WordPress builds — fast, secure, and easy for your team to run.",
    headline: ["WordPress without", "the bloat."],
    intro:
      "WordPress powers 40% of the web — and most of it badly. We build custom WordPress sites the disciplined way: lean custom themes, no plugin soup, editor experiences your team will actually enjoy, and security hardened from day one.",
    problem: {
      title: "Most WordPress sites are one plugin update away from disaster.",
      points: [
        "A purchased theme plus 40 plugins: slow, fragile, and impossible for anyone to maintain confidently.",
        "The admin is so cluttered your team is scared to touch it — so content stays stale.",
        "No staging, no backups, no updates policy. Then one day the site is down or hacked.",
      ],
    },
    solution:
      "We build custom block-based themes with only the plugins that earn their place. Your editors get clean, structured editing — not a page-builder maze. Performance is engineered (caching, image pipelines, database hygiene) and security is layered: hardening, monitoring, automated backups and managed updates through our care plans.",
    benefits: [
      { title: "Custom theme, zero bloat", desc: "Hand-built for your brand and content model. Typical result: pages load in under a second." },
      { title: "An admin your team loves", desc: "Structured blocks and fields for your real content types — anyone can update the site safely." },
      { title: "Hardened security", desc: "Locked-down configuration, monitoring, and managed updates so vulnerabilities are patched before they're exploited." },
      { title: "SEO-ready architecture", desc: "Clean markup, schema, and full control of every on-page element your SEO strategy needs." },
    ],
    process: [
      { title: "Scope & content model", desc: "Pages, post types and editorial workflows defined before design begins." },
      { title: "Design", desc: "Custom UI design in Figma, mapped one-to-one to the block system you'll edit with." },
      { title: "Theme build", desc: "Lean custom theme, custom blocks, and only battle-tested plugins." },
      { title: "Migrate & QA", desc: "Content migration, redirects, device and performance testing on staging." },
      { title: "Launch & care", desc: "Go-live, editor training, and managed hosting/updates if you want us on call." },
    ],
    outcomes: [
      { value: "<1s", label: "typical load time for our custom WordPress builds" },
      { value: "−80%", label: "plugin count after a typical rescue project" },
      { value: "100%", label: "of our WP builds ship with staging, backups and update policy" },
    ],
    tools: ["WordPress", "Custom Gutenberg blocks", "ACF", "WP Rocket", "Cloudflare", "ManageWP"],
    faqs: [
      { q: "Can you fix or speed up our existing WordPress site?", a: "Yes — rescue and performance projects are common starting points. We audit first, then either optimise what exists or recommend a rebuild with evidence for the choice." },
      { q: "Custom theme or page builder?", a: "Custom theme with native blocks, almost always. It's faster, more secure and easier to edit than Elementor-style builders once the site matters commercially." },
      { q: "Will you maintain the site after launch?", a: "Care plans cover updates, backups, security monitoring, uptime and a monthly improvement allowance. Most clients take one; none are locked in." },
      { q: "Can WordPress handle multilingual / multi-location?", a: "Yes — we build multilingual and multi-site setups regularly, including hreflang and localised SEO done properly." },
    ],
    related: ["website-development", "seo", "shopify-development"],
  },
  {
    slug: "shopify-development",
    name: "Shopify Development",
    category: "Web & Technology",
    short: "Shopify stores designed to convert and engineered to scale.",
    headline: ["Stores that sell", "while you sleep."],
    intro:
      "We design and build Shopify and Shopify Plus stores that feel like brands, not templates — custom themes, conversion-obsessed product pages, and the app and integration architecture to grow from first sale to full scale.",
    problem: {
      title: "Template stores hit a ceiling fast.",
      points: [
        "Your store looks like a thousand others, so price becomes the only differentiator.",
        "Conversion rate is stuck — traffic arrives, carts abandon, and nobody knows which fix matters.",
        "Apps stacked on apps: slow pages, conflicting scripts and monthly fees for features half-used.",
      ],
    },
    solution:
      "We build custom Shopify themes around your brand and your buyer's journey — fast product pages with persuasive structure (social proof, offers, sizing confidence, delivery clarity), streamlined checkout, and a deliberately minimal app stack. Post-launch, our CRO sprints and lifecycle email work turn the store into a compounding revenue machine.",
    benefits: [
      { title: "A store that feels like your brand", desc: "Custom theme design and Liquid/Hydrogen development — distinctive where it persuades, standard where it converts." },
      { title: "Conversion engineering", desc: "Every template built from CRO evidence: PDP structure, trust signals, urgency done honestly, frictionless checkout." },
      { title: "Speed on mobile", desc: "Most of your buyers are on phones. We keep scripts lean so pages load before intent fades." },
      { title: "Scale-ready architecture", desc: "ERP, logistics, WhatsApp commerce and marketplace integrations built cleanly — ready for Shopify Plus when you are." },
    ],
    process: [
      { title: "Store & data audit", desc: "Analytics, funnel and competitor review; migration planning if you're moving platforms." },
      { title: "UX & design", desc: "Purchase-journey mapping, then custom design for every key template." },
      { title: "Theme development", desc: "Custom theme build with clean, documented code and a minimal app stack." },
      { title: "Migration & launch", desc: "Products, customers, orders and SEO redirects moved without losing rankings or history." },
      { title: "CRO & growth", desc: "Post-launch experiment sprints, lifecycle email flows and performance marketing alignment." },
    ],
    outcomes: [
      { value: "+87%", label: "conversion rate lift after a skincare brand's redesign" },
      { value: "1.2s", label: "mobile product-page loads after app-stack cleanup" },
      { value: "+41%", label: "AOV via bundling and post-purchase flows for a D2C client" },
    ],
    tools: ["Shopify / Shopify Plus", "Liquid", "Hydrogen", "Klaviyo", "Judge.me", "GA4"],
    faqs: [
      { q: "Can you migrate us from WooCommerce/Magento?", a: "Yes — products, customers, order history and URL redirects handled with a rankings-preservation checklist. Migrations are one of our most requested projects." },
      { q: "Custom theme or a premium theme customised?", a: "Depends on stage. Early stores often start on a customised premium theme; growing brands get full custom builds. We'll recommend honestly based on your revenue and roadmap." },
      { q: "Do you also run the marketing for the store?", a: "That's the advantage — one team for the build, the Meta/Google ads, the email flows and the CRO. No finger-pointing between agencies." },
      { q: "Do you work with Shopify Plus?", a: "Yes, including checkout extensibility, B2B features, scripts/functions and multi-store international setups." },
    ],
    related: ["website-development", "meta-ads", "email-marketing"],
  },
  {
    slug: "ai-automation",
    name: "AI Automation",
    category: "Web & Technology",
    short: "Put AI to work on the repetitive 40% of your business.",
    headline: ["Hire software that", "never sleeps."],
    intro:
      "AI stopped being a demo and became a workforce. We build practical AI automations — lead qualification bots, WhatsApp assistants, content pipelines, CRM workflows and internal copilots — that remove hours of repetitive work and respond to customers in seconds, not shifts.",
    problem: {
      title: "Your team's best hours go to work a machine should do.",
      points: [
        "Leads arrive at midnight and get answered at noon — after they've spoken to a faster competitor.",
        "Sales, support and operations copy-paste between tools that were never connected.",
        "You know AI could help, but pilots keep stalling because nobody bridges the gap between the tech and your actual process.",
      ],
    },
    solution:
      "We start with a process audit, not a technology pitch: where do hours leak, where do leads cool, where do errors creep in. Then we build targeted automations — AI chat and WhatsApp assistants trained on your business, lead scoring and routing, document and content generation with human review, and integrations that make your existing tools talk. Each automation ships with guardrails, monitoring and a measurable before/after.",
    benefits: [
      { title: "Instant response, every channel", desc: "AI assistants on your website and WhatsApp qualify leads and answer FAQs 24/7 — handing hot prospects to humans with full context." },
      { title: "Workflows without the busywork", desc: "CRM updates, follow-up sequences, report generation and data entry automated across the tools you already use." },
      { title: "Content at scale, quality kept", desc: "AI-assisted pipelines for drafts, variants and localisation — with editorial review built into the loop." },
      { title: "Guardrails included", desc: "Brand-safe prompts, escalation rules, logging and human handoff. Automation you can trust in front of customers." },
    ],
    process: [
      { title: "Automation audit", desc: "We map your workflows and rank automation opportunities by hours saved and revenue impact." },
      { title: "Pilot design", desc: "One high-impact use case, defined success metrics, quick build." },
      { title: "Build & integrate", desc: "Assistants, flows and integrations built on proven platforms — connected to your CRM and channels." },
      { title: "Test with guardrails", desc: "Real scenarios, edge cases, escalation paths and tone checks before anything goes live." },
      { title: "Scale & monitor", desc: "Rollout across teams with dashboards, monthly tuning and new use cases added by ROI." },
    ],
    outcomes: [
      { value: "<60s", label: "lead response time (from 6+ hours) for a real-estate client's WhatsApp assistant" },
      { value: "35h", label: "of manual work saved weekly for an operations team via CRM automation" },
      { value: "+27%", label: "lead-to-meeting conversion after instant qualification and routing" },
    ],
    tools: ["OpenAI / Claude APIs", "Zapier / Make", "n8n", "WhatsApp Business API", "HubSpot / Zoho", "Airtable"],
    faqs: [
      { q: "Will an AI assistant embarrass our brand?", a: "Not the way we build them. Assistants are scoped to what they know, tested against edge cases, and escalate to humans the moment confidence drops. You approve the voice and the boundaries." },
      { q: "We're not technical — is this for us?", a: "Especially for you. We handle the technology end-to-end and train your team on simple dashboards. If your business runs on WhatsApp, email and spreadsheets, there's usually enormous low-hanging fruit." },
      { q: "What does it cost?", a: "Pilots typically start as small fixed-scope projects so you can measure ROI before committing further. Ongoing platform costs are transparent and mostly usage-based." },
      { q: "What about our data?", a: "We design for privacy: minimal data sent to models, provider agreements reviewed, and where needed, region-appropriate hosting. You get a plain-language data map of every automation." },
    ],
    related: ["website-development", "email-marketing", "google-ads"],
  },

  /* ---------------------------- BRAND & CONTENT ---------------------------- */
  {
    slug: "branding",
    name: "Branding",
    category: "Brand & Content",
    short: "Identity systems that make your business unmistakable.",
    headline: ["Become the brand", "they remember."],
    intro:
      "A brand is the shortcut customers use to choose you. We build complete identity systems — strategy, naming, logo, voice, and guidelines — that compress everything your business stands for into something people recognise in half a second.",
    problem: {
      title: "If customers can't tell you apart, they'll decide on price.",
      points: [
        "Your visual identity was made quickly years ago and no longer matches the business you've become.",
        "Every touchpoint — site, decks, social, packaging — looks like it came from a different company.",
        "You're entering new markets or raising investment, and the brand undersells the substance behind it.",
      ],
    },
    solution:
      "We start with strategy: positioning, audience, personality and the one idea your brand should own. Then we design the system — logo and marks, colour, typography, art direction, voice and messaging — and prove it across your real touchpoints before handing over guidelines your whole team (and every future vendor) can follow. Not just a logo file: an operating system for how your business shows up.",
    benefits: [
      { title: "Strategy before aesthetics", desc: "Positioning workshops and market analysis so the identity expresses a real, defensible difference." },
      { title: "A complete system", desc: "Logo suite, palette, type, iconography, imagery style, motion principles and tone of voice — everything a growing brand touches." },
      { title: "Proven in the wild", desc: "We design the identity on your actual touchpoints — website, packaging, pitch deck, storefront — not just on a mood board." },
      { title: "Guidelines people use", desc: "Practical, example-rich brand guidelines and asset libraries that keep the brand consistent without policing." },
    ],
    process: [
      { title: "Discovery & strategy", desc: "Stakeholder interviews, market and competitor analysis, positioning and messaging platform." },
      { title: "Creative directions", desc: "Two to three distinct identity routes explored on real applications." },
      { title: "Design & refine", desc: "Chosen route developed into the full system with your feedback at each round." },
      { title: "Rollout design", desc: "Priority applications — website, social kit, stationery, signage, packaging — designed and prepared." },
      { title: "Guidelines & handover", desc: "Brand book, asset library and a working session with your team." },
    ],
    outcomes: [
      { value: "6 wks", label: "typical timeline from kickoff to a complete identity system" },
      { value: "3", label: "creative routes explored before we commit — decided on strategy, not taste" },
      { value: "100%", label: "of brand projects delivered with usable guidelines, not just logo files" },
    ],
    tools: ["Figma", "Adobe Illustrator", "After Effects", "Notion brand portals"],
    faqs: [
      { q: "We just need a logo — can you do that?", a: "We can, but a logo without positioning is a coin flip. Our smallest brand package includes enough strategy to make the design decision defensible — it costs a little more and is worth ten times the difference." },
      { q: "How do you handle rebrands with existing equity?", a: "Carefully. We audit what customers actually recognise and value, keep that, and evolve the rest. Revolution when needed, evolution when it's wiser." },
      { q: "What do we receive at the end?", a: "All source files, exports for every use case, a brand guidelines document, and a licensed font/asset list. Everything is yours outright." },
      { q: "Can you also apply the brand everywhere afterwards?", a: "Yes — that's where we're different from a pure branding studio. The same house builds your website, runs your social and produces your ads, so the brand stays coherent in daily use." },
    ],
    related: ["graphic-design", "website-development", "social-media-marketing"],
  },
  {
    slug: "graphic-design",
    name: "Graphic Design",
    category: "Brand & Content",
    short: "Design that looks expensive and works hard — on every surface.",
    headline: ["Craft in every", "pixel and page."],
    intro:
      "From pitch decks that win rooms to packaging that sells off the shelf, our design studio produces work with real craft: brochures, ad creative, social kits, exhibition graphics, catalogues and everything in between — always on-brand, always on time.",
    problem: {
      title: "Inconsistent design quietly erodes trust.",
      points: [
        "Your materials are made by whoever's available — a freelancer here, Canva there — and it shows.",
        "Deadlines force compromises: the trade show is next week and the booth graphics are an afterthought.",
        "Your product is premium but your collateral says budget.",
      ],
    },
    solution:
      "We operate as your design department on demand. A senior-led studio that learns your brand deeply, keeps an organised asset system, and delivers everything from a single social tile to a 60-page annual report with the same standard of craft. Fixed monthly design retainers or per-project scopes — whichever fits how you work.",
    benefits: [
      { title: "Senior craft, consistent output", desc: "Every deliverable passes through art direction. No junior-only work sneaking into your brand." },
      { title: "Print and digital fluency", desc: "Packaging dielines and press-ready files, or pixel-perfect digital assets — one studio, both worlds done properly." },
      { title: "Speed without the scramble", desc: "Retainer clients get guaranteed turnaround times and a shared production calendar." },
      { title: "A living asset system", desc: "Organised, versioned brand assets so nothing is redrawn from scratch and nothing goes off-brand." },
    ],
    process: [
      { title: "Brief & immersion", desc: "We absorb your brand guidelines — or tighten them if they're loose." },
      { title: "Concept", desc: "Directions presented with rationale, not just options." },
      { title: "Design & iterate", desc: "Structured feedback rounds with fast, tracked revisions." },
      { title: "Production", desc: "Print-ready or dev-ready files, prepress checks, vendor coordination if needed." },
      { title: "Asset handover", desc: "Organised source files delivered to your library, every time." },
    ],
    outcomes: [
      { value: "48h", label: "standard turnaround for retainer social and ad assets" },
      { value: "300+", label: "assets produced monthly across our design retainers" },
      { value: "2 rounds", label: "average revisions to approval — briefs done right the first time" },
    ],
    tools: ["Adobe Creative Suite", "Figma", "After Effects", "Blender", "Print production partners"],
    faqs: [
      { q: "How does a design retainer work?", a: "A monthly block of design capacity with guaranteed turnarounds and a dedicated designer who knows your brand. Unused capacity partially rolls over; scope flexes month to month." },
      { q: "Do you do packaging and print?", a: "Yes — dielines, materials guidance, prepress and print-vendor coordination included. We've shipped packaging, signage, exhibition booths and full catalogues." },
      { q: "Can you match our existing brand style?", a: "Precisely — that's table stakes. If your guidelines have gaps, we'll flag and fix them so consistency gets easier for everyone." },
      { q: "What if we need something in 24 hours?", a: "Retainer clients get priority lanes for genuine emergencies. We'll always be honest about what's achievable without sacrificing quality." },
    ],
    related: ["branding", "social-media-marketing", "video-marketing"],
  },
  {
    slug: "video-marketing",
    name: "Video Marketing",
    category: "Brand & Content",
    short: "Video that earns attention — from 15-second hooks to brand films.",
    headline: ["Say it in motion.", "Make it stick."],
    intro:
      "Video is the highest-bandwidth way to build trust at scale. We script, shoot and edit everything from scroll-stopping Reels and performance ad creative to product films and founder stories — then distribute them where your buyers actually watch.",
    problem: {
      title: "Everyone knows video works. Few can produce it consistently.",
      points: [
        "One expensive brand video sits on your homepage while your social feeds starve for content.",
        "Ad campaigns underperform because the creative wasn't made for the platform — TV thinking in a Reels world.",
        "In-house attempts stall: shooting is easy, but scripting, editing and consistency are where it falls apart.",
      ],
    },
    solution:
      "We build a video engine, not a one-off production. Quarterly shoot days generate batches of raw material; our editors turn them into platform-native cuts — Reels, YouTube, ads, testimonials, product explainers — on a steady calendar. Performance data feeds back into scripts, so the content gets sharper every month.",
    benefits: [
      { title: "Batch production economics", desc: "One well-planned shoot day yields 15–30 finished assets. Premium quality at a per-asset cost that makes consistency affordable." },
      { title: "Platform-native editing", desc: "Hooks in the first second, captions always, aspect ratios and pacing tuned per platform — not one file exported five ways." },
      { title: "Performance-informed scripts", desc: "Ad creative built from hooks and angles that testing proves, especially for Meta and YouTube campaigns." },
      { title: "Full-stack production", desc: "Scripting, storyboards, direction, shooting, motion graphics, sound and colour — all in-house or under our direction." },
    ],
    process: [
      { title: "Video strategy", desc: "Audience, platforms, formats and a 90-day content slate." },
      { title: "Scripts & storyboards", desc: "Every video planned on paper first — hooks, structure, CTA." },
      { title: "Shoot days", desc: "Efficient, directed production on location or in studio." },
      { title: "Edit & versions", desc: "Platform-native cuts, motion graphics, subtitles and thumbnails." },
      { title: "Publish & learn", desc: "Distribution, performance review and next slate informed by the data." },
    ],
    outcomes: [
      { value: "24", label: "finished video assets from a typical quarterly shoot day" },
      { value: "3.4×", label: "watch-through rate vs. client's previous ad creative" },
      { value: "70%", label: "of our Meta ad winners are video-led" },
    ],
    tools: ["Premiere Pro", "After Effects", "DaVinci Resolve", "CapCut", "Frame.io", "Sony cinema line"],
    faqs: [
      { q: "Do you shoot outside Bengaluru?", a: "Yes — we shoot across India regularly and coordinate productions in Dubai, Sydney and Europe through our offices and partner crews." },
      { q: "Can you make ads from footage we already have?", a: "Often, yes. Send us your drive — good editors can mine gold from existing footage, and we'll tell you honestly what needs a reshoot." },
      { q: "What does video cost?", a: "Batch days make it affordable: most clients run a quarterly production retainer that works out to a fraction of per-video agency pricing. One-off brand films are quoted per project." },
      { q: "Do you handle YouTube strategy too?", a: "Yes — channel strategy, titles/thumbnails, publishing and YouTube ads sit alongside production so the videos actually get watched." },
    ],
    related: ["social-media-marketing", "meta-ads", "content-marketing"],
  },
  {
    slug: "content-marketing",
    name: "Content Marketing",
    category: "Brand & Content",
    short: "Content that ranks, persuades and compounds — not filler.",
    headline: ["Publish like you", "mean business."],
    intro:
      "Content marketing is how you sell to people who aren't ready to buy yet — and how they find you when they are. We build editorial engines: strategy, writing, design and distribution that turn your expertise into rankings, trust and pipeline.",
    problem: {
      title: "A blog nobody reads isn't a content strategy.",
      points: [
        "Publishing stopped because nobody could keep feeding it — the last post is from 2023.",
        "What exists is generic: AI-flavoured articles that could sit on any competitor's site.",
        "No connection to SEO or sales, so even decent content never shows up in revenue conversations.",
      ],
    },
    solution:
      "We mine content from where it actually lives: your sales calls, your delivery team, your customers' questions. Each quarter gets a content slate mapped to keywords and funnel stages — cornerstone guides, comparison pages, case stories, newsletters — written by humans with editorial standards, designed properly, and distributed across search, social and email rather than left to be discovered.",
    benefits: [
      { title: "Expertise, extracted", desc: "Interviews with your team turn tacit knowledge into content competitors can't copy — because it's genuinely yours." },
      { title: "SEO-integrated planning", desc: "Every piece maps to a keyword and a funnel stage. Content and SEO run as one program, not two invoices." },
      { title: "Designed, not just written", desc: "Custom graphics, diagrams and formatting that make long-form content readable and shareable." },
      { title: "Distribution built in", desc: "Republishing, social atomisation and email — one cornerstone piece becomes ten touchpoints." },
    ],
    process: [
      { title: "Content audit & strategy", desc: "What you have, what ranks, what's missing against the buyer journey." },
      { title: "Quarterly slate", desc: "A prioritised calendar mapped to keywords, campaigns and sales priorities." },
      { title: "Research & interviews", desc: "Subject-matter interviews and original research for every cornerstone piece." },
      { title: "Write, design, publish", desc: "Editorial-quality production with on-page SEO handled." },
      { title: "Distribute & measure", desc: "Atomisation across channels; rankings, engagement and attributed pipeline reported monthly." },
    ],
    outcomes: [
      { value: "+480%", label: "organic blog traffic in a year for a B2B SaaS client" },
      { value: "12", label: "sales conversations attributed to one cornerstone guide in its first quarter" },
      { value: "10+", label: "assets atomised from each cornerstone piece" },
    ],
    tools: ["Ahrefs", "Semrush", "Notion", "Figma", "Grammarly", "GA4"],
    faqs: [
      { q: "Do you use AI to write?", a: "We use AI for research assists and variants; the thinking, interviews and final writing are human. The goal is content with information gain — things only your business can say." },
      { q: "How much content do we need?", a: "Less than you think, better than you have. Two to four excellent pieces a month, properly distributed, beats daily filler every time." },
      { q: "Can you write for technical/regulated industries?", a: "Yes — our process is interview-led precisely so accuracy comes from your experts, and compliance review fits into the workflow (healthcare, finance, legal)." },
      { q: "How do you prove ROI?", a: "Rankings and traffic as leading indicators; attributed enquiries, assisted conversions and content-influenced pipeline as the real scoreboard." },
    ],
    related: ["seo", "email-marketing", "social-media-marketing"],
  },
  {
    slug: "email-marketing",
    name: "Email Marketing",
    category: "Brand & Content",
    short: "The highest-ROI channel in marketing — finally done properly.",
    headline: ["Own the inbox,", "own the relationship."],
    intro:
      "Email is the only channel where you own the audience. We build lifecycle email programs — welcome journeys, nurture sequences, campaigns and e-commerce flows — that turn your list from a dusty asset into a dependable revenue line.",
    problem: {
      title: "Your list is an asset earning nothing.",
      points: [
        "Thousands of contacts, one occasional newsletter — sent when someone remembers.",
        "No automation: new leads get no welcome, abandoned carts get no nudge, past customers get no reason to return.",
        "Deliverability is quietly broken, so even good emails land in spam and nobody notices.",
      ],
    },
    solution:
      "We design the lifecycle first: every stage from first touch to loyal customer gets mapped, then automated. Welcome series, nurture tracks, cart and browse abandonment, win-backs, post-purchase journeys and campaign calendars — written in your voice, designed on-brand, and built on solid deliverability (authentication, list hygiene, warm-up). Reported in revenue, not open rates.",
    benefits: [
      { title: "Automated revenue flows", desc: "The 20% of flows that drive 80% of email revenue — welcome, abandonment, post-purchase, win-back — built and optimised." },
      { title: "Deliverability engineering", desc: "SPF/DKIM/DMARC, domain warm-up, list hygiene and placement monitoring. Inbox first, creativity second." },
      { title: "Segmentation with a purpose", desc: "Behaviour- and value-based segments so people get email that's relevant enough to keep opening." },
      { title: "Voice-true copy and design", desc: "Emails that sound like your brand and render beautifully everywhere, dark mode included." },
    ],
    process: [
      { title: "Audit & lifecycle map", desc: "List health, deliverability, current flows and the revenue being left on the table." },
      { title: "Flow architecture", desc: "Every automated journey specified: triggers, timing, branches, goals." },
      { title: "Copy & design", desc: "On-brand templates and sequence copy, reviewed with you." },
      { title: "Build & test", desc: "Flows built in your ESP, rendering and deliverability tested before launch." },
      { title: "Optimise monthly", desc: "A/B tests on subject lines, timing and offers; campaign calendar runs alongside." },
    ],
    outcomes: [
      { value: "31%", label: "of a Shopify client's revenue now attributed to email flows" },
      { value: "+220%", label: "list growth in six months via lead magnets and popups done tastefully" },
      { value: "98.5%", label: "inbox placement after deliverability remediation" },
    ],
    tools: ["Klaviyo", "Mailchimp", "HubSpot", "Brevo", "Litmus", "Figma"],
    faqs: [
      { q: "Which platform do you recommend?", a: "Klaviyo for e-commerce, HubSpot or Brevo for B2B and services — but we work in your existing ESP if it's capable. Migration is straightforward when it isn't." },
      { q: "How often should we email?", a: "More than you fear, less than spam: typically weekly campaigns plus automated flows. Frequency earns itself when relevance is high — we'll find your list's tolerance with data." },
      { q: "Our open rates are terrible. Fixable?", a: "Usually, yes. It's almost always deliverability (authentication, list decay) plus relevance. Our audits find the cause in week one." },
      { q: "Do you handle compliance (GDPR etc.)?", a: "We build consent, preference centres and unsubscribe handling to GDPR/CAN-SPAM standards, and follow regional rules for the markets you send to." },
    ],
    related: ["content-marketing", "shopify-development", "ai-automation"],
  },
];

export const getService = (slug: string) => services.find((s) => s.slug === slug);

export const servicesByCategory = () =>
  serviceCategories.map((cat) => ({
    category: cat,
    items: services.filter((s) => s.category === cat),
  }));
