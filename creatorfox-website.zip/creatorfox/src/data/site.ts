export const site = {
  name: "CreatorFox",
  tagline: "Outfox the market.",
  description:
    "CreatorFox is a global digital marketing and web development agency. We build brands, websites and growth engines for ambitious businesses across India, the UAE, Australia and Germany.",
  url: "https://creatorfox.com",
  email: "make@creatorfox.com",
  phone: "+91 77605 25535",
  phoneHref: "+917760525535",
  whatsapp: "https://wa.me/917760525535",
  calendly: "https://calendly.com/creatorfox/strategy-call", // placeholder — replace with your live Calendly URL
  founded: 2018,
  social: {
    instagram: "https://instagram.com/creatorfox",
    linkedin: "https://linkedin.com/company/creatorfox",
    facebook: "https://facebook.com/creatorfox",
    youtube: "https://youtube.com/@creatorfox",
  },
} as const;

export const offices = [
  {
    city: "Bengaluru",
    country: "India",
    label: "Head office",
    address:
      "#1, 1st Main Rd, 2nd B Cross, Chikka Bommasandra, Yelahanka New Town, Bengaluru 560065",
    phone: "+91 77605 25535",
    timezone: "IST",
    coords: { x: 66.5, y: 55 }, // % positions on the world map graphic
  },
  {
    city: "Dubai",
    country: "UAE",
    label: "Middle East",
    address: "26th St, Al Qusais Industrial Area 3, Dubai, United Arab Emirates",
    phone: "+971 56 902 9386",
    timezone: "GST",
    coords: { x: 60, y: 48 },
  },
  {
    city: "Sydney",
    country: "Australia",
    label: "APAC",
    address: "Suite 7, 186 Canterbury Road, Canterbury NSW 2193, Australia",
    phone: "+61 2 7258 8677",
    timezone: "AEST",
    coords: { x: 87, y: 78 },
  },
  {
    city: "Dortmund",
    country: "Germany",
    label: "Europe",
    address: "Hohenfriedberger Str. 4, 44141 Dortmund, Germany",
    phone: "+49 176 4197 6299",
    timezone: "CET",
    coords: { x: 48.5, y: 32 },
  },
] as const;

/*
 * Headline numbers used across the site.
 * NOTE: verify each figure before launch — see README "Content to verify".
 */
export const stats = [
  { value: 250, suffix: "+", label: "Clients served worldwide" },
  { value: 4, suffix: "", label: "Offices on 3 continents" },
  { value: 640, suffix: "+", label: "Projects shipped" },
  { value: 93, suffix: "%", label: "Clients who stay past year one" },
] as const;

export const industries = [
  {
    name: "Real Estate",
    blurb:
      "Lead engines for developers and brokerages — from property landing pages to hyper-local Google Ads that fill site visits.",
  },
  {
    name: "Healthcare",
    blurb:
      "Compliant, trust-first marketing for clinics and hospitals: local SEO, reputation management and patient-journey websites.",
  },
  {
    name: "E-commerce & D2C",
    blurb:
      "Shopify builds, conversion optimisation and full-funnel Meta + Google campaigns that turn ad spend into repeat customers.",
  },
  {
    name: "SaaS & Technology",
    blurb:
      "Positioning, content engines and demand generation that explain complex products simply and fill the pipeline.",
  },
  {
    name: "Education",
    blurb:
      "Admissions-season campaigns, course landing pages and always-on content that keeps institutions top of mind.",
  },
  {
    name: "Hospitality & Food",
    blurb:
      "Menus people crave before they arrive — social content, influencer collabs and Google Business profiles that drive footfall.",
  },
  {
    name: "Manufacturing & B2B",
    blurb:
      "Catalogue websites, LinkedIn demand programs and SEO that put industrial brands in front of serious buyers.",
  },
  {
    name: "Finance & Professional Services",
    blurb:
      "Authority-building content, lead-qualified funnels and websites that make expertise legible and credible.",
  },
] as const;

export const testimonials = [
  {
    quote:
      "CreatorFox rebuilt our website and took over our Google Ads. Within a quarter our cost per lead dropped by more than half — and the leads actually close.",
    name: "Rohit S.",
    role: "Director, real estate development group",
  },
  {
    quote:
      "They run our SEO and content like an in-house team. Traffic is up, but more importantly the right people find us and book consultations.",
    name: "Dr. Ananya M.",
    role: "Founder, multi-speciality clinic",
  },
  {
    quote:
      "Our Shopify store went from a template to a brand. Conversion rate nearly doubled after the redesign and the CRO sprints that followed.",
    name: "Fatima K.",
    role: "Co-founder, D2C skincare brand, Dubai",
  },
  {
    quote:
      "Fast, honest and relentlessly commercial. Every monthly report links spend to revenue — no vanity metrics, no jargon.",
    name: "Markus B.",
    role: "Managing director, B2B manufacturer, Dortmund",
  },
] as const;

export const homeFaqs = [
  {
    q: "What does CreatorFox actually do?",
    a: "We're a full-service digital agency. One team covers strategy, branding, website and e-commerce development, SEO, paid media on Google and Meta, content, email and AI automation — so your growth doesn't fall through the gaps between vendors.",
  },
  {
    q: "Where do you work from?",
    a: "Our head office is in Bengaluru, with teams in Dubai, Sydney and Dortmund. We work with clients across India, the Middle East, Australia, Europe and North America — timezone overlap is planned into every engagement.",
  },
  {
    q: "How do engagements usually start?",
    a: "With a free strategy call. We audit what you have, show you the gaps and opportunities, and propose a scope with clear deliverables and timelines. No retainer lock-in before you've seen how we think.",
  },
  {
    q: "How do you report results?",
    a: "Monthly, in plain language, tied to business outcomes: leads, revenue, cost per acquisition. Every client gets a live dashboard plus a summary a founder can read in five minutes.",
  },
  {
    q: "What does it cost?",
    a: "Projects are scoped individually. Websites typically start as fixed-price builds; marketing runs as monthly retainers sized to your channels and market. Tell us your goal on the strategy call and we'll give you a straight number.",
  },
  {
    q: "Do you work with startups or only established brands?",
    a: "Both. We've launched first websites for founders and run multi-country campaigns for established groups. What we need from you is a real product and the intent to grow — we'll build the rest.",
  },
] as const;
